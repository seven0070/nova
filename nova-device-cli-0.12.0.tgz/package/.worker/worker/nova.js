"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = main;
const setup_1 = require("./setup");
const doctor_1 = require("./doctor");
const router_1 = require("./router");
const promises_1 = require("node:readline/promises");
const node_process_1 = require("node:process");
const node_path_1 = __importDefault(require("node:path"));
const node_crypto_1 = require("node:crypto");
const remote_1 = require("./coding/remote");
const config_1 = require("./coding/config");
const store_1 = require("./coding/store");
const files_1 = require("./coding/files");
const runner_1 = require("./coding/runner");
const backend_1 = require("./coding/backend");
const HELP = `Nova Code CLI 0.12.0

nova setup backend|local|connect             Guided configuration with hidden key entry
nova connect https://your-backend.example    Connect and save a scoped backend token
nova                                        Interactive coding chat in this project
nova -p "Review this code" --plan             Read-only one-shot / piped context
nova --continue                             Continue the newest project session
nova resume SESSION_ID                      Resume a local or cloud session
nova sessions                               List project sessions
nova models                                 Show allowed backend models
nova context pull|push                      Sync shared goals, profiles and notes
nova context-session SESSION_ID             Import a hub conversation into this project
nova verify                                 Test one real model decision through the backend
nova doctor                                 Check backend and project connection
nova backend                                Start the deployable backend
nova pair URL                               Pair this device using a hidden one-use code
nova devices list|pair LABEL|revoke ID       Administer your paired device tokens
nova backend-health                         Inspect usage, queue and audit summary
nova backend-backup                         Create a protected SQLite snapshot on the host

--project PATH         Project root (defaults to current directory)
--project-id NAME      Stable identity for the same repo on multiple devices
--backend URL          Override URL; token must match that backend
--scopes LIST          Pairing scopes, comma separated (default all device scopes)
--execution MODE       docker (default), native (explicit host commands), none
--plan                 Read-only planning mode
--model ID             Choose an allowed backend model
--max-steps 2..40       Agent decision limit (default 20)
--json                 One-shot structured result; all logs go to stderr
--direct               Use NOVA_MODEL_* locally instead of a Nova backend
--help / --version

Interactive: /help /plan /code /diff /status /undo /new /retry /sessions /model ID /exit
Model provider keys stay on the backend. Local code/tool results sent for inference
are visible to that backend. All edits and commands require interactive approval.
`;
function argsOf(argv) { const out = { _: [] }; const values = new Set(['project', 'project-id', 'backend', 'execution', 'max-steps', 'model', 'resume', 'p', 'print', 'scopes']); const bool = new Set(['help', 'version', 'plan', 'json', 'direct', 'continue']); for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (!arg.startsWith('-')) {
        out._.push(arg);
        continue;
    }
    const [name, inline] = arg.replace(/^--?/, '').split('=', 2);
    if (values.has(name)) {
        const value = inline ?? argv[++i];
        if (value === undefined || value.startsWith('--'))
            throw new Error('Missing value for --' + name);
        out[name] = value;
    }
    else if (bool.has(name)) {
        if (inline)
            throw new Error('--' + name + ' does not take a value');
        out[name] = true;
    }
    else
        throw new Error('Unknown option ' + arg);
} return out; }
async function pipeInput() { let text = '', bytes = 0; for await (const part of node_process_1.stdin) {
    bytes += part.length;
    if (bytes > 60000)
        throw new Error('Piped context exceeds 60 KB');
    text += part.toString();
} return text; }
async function main(argv = process.argv.slice(2)) {
    const args = argsOf(argv);
    if (args.help) {
        node_process_1.stdout.write(HELP);
        return;
    }
    if (args.version) {
        node_process_1.stdout.write('0.12.0\n');
        return;
    }
    if (args._[0] === 'setup') {
        await (0, setup_1.setupWizard)(args._[1] || 'connect', node_path_1.default.resolve(args.project || process.cwd()));
        return;
    }
    if (args._[0] === 'verify') {
        node_process_1.stdout.write(JSON.stringify(await (0, setup_1.verifyBackend)(await (0, config_1.remoteConfig)(args.backend)), null, 2) + '\n');
        return;
    }
    if (args._[0] === 'backend') {
        await (0, backend_1.startBackend)();
        return;
    }
    if (args._[0] === 'pair') {
        node_process_1.stdout.write(JSON.stringify(await (0, setup_1.pairDevice)(args._[1] || args.backend || '', process.env.NOVA_PAIR_CODE), null, 2) + '\n');
        return;
    }
    if (['devices', 'backend-health', 'backend-backup'].includes(args._[0])) {
        const client = new remote_1.BackendClient(await (0, config_1.remoteConfig)(args.backend));
        let route = '/v1/admin/health', options = {};
        if (args._[0] === 'backend-backup') {
            route = '/v1/admin/backup';
            options = { method: 'POST' };
        }
        if (args._[0] === 'devices') {
            const action = args._[1];
            if (action === 'list')
                route = '/v1/admin/devices';
            else if (action === 'pair') {
                route = '/v1/admin/pair';
                options = { method: 'POST', body: JSON.stringify({ label: args._[2], scopes: args.scopes ? args.scopes.split(',') : undefined }) };
            }
            else if (action === 'revoke') {
                route = '/v1/admin/revoke';
                options = { method: 'POST', body: JSON.stringify({ id: args._[2] }) };
            }
            else
                throw new Error('Use nova devices list, nova devices pair LABEL or nova devices revoke ID');
        }
        node_process_1.stdout.write(JSON.stringify(await (await client.request(route, options)).json(), null, 2) + '\n');
        return;
    }
    if (args._[0] === 'connect') {
        const backend = (0, config_1.backendUrl)(args._[1] || args.backend || '');
        const token = process.env.NOVA_BACKEND_TOKEN || '';
        if (token.length < 32)
            throw new Error('Set NOVA_BACKEND_TOKEN to the backend-issued token before connecting (never put it in a command argument)');
        const client = new remote_1.BackendClient({ backend, token });
        const info = await client.info();
        await (0, config_1.saveConfig)({ backend, token });
        node_process_1.stdout.write('Connected to ' + backend + ' · ' + info.model + '\nToken saved with owner-only file permissions.\n');
        return;
    }
    const root = await (0, files_1.projectRoot)(node_path_1.default.resolve(args.project || process.cwd()));
    const projectId = (0, node_crypto_1.createHash)('sha256').update(args['project-id'] || root).digest('hex').slice(0, 32), store = new store_1.DeviceStore(projectId);
    let backend;
    if (!args.direct) {
        try {
            backend = new remote_1.BackendClient(await (0, config_1.remoteConfig)(args.backend));
        }
        catch (e) {
            if (args._[0] !== 'doctor')
                throw e;
        }
    }
    const log = (text) => (args.json ? node_process_1.stderr : node_process_1.stdout).write((0, files_1.clean)(text) + '\n');
    const directGateway = args.direct ? await (0, router_1.loadDeviceGateway)() : undefined;
    if (args.model) {
        if (directGateway)
            process.env.NOVA_ROUTE = args.model;
        else if (backend)
            backend.model = args.model;
        else
            process.env.NOVA_MODEL = args.model;
    }
    if (args._[0] === 'models') {
        log(JSON.stringify(backend ? (await backend.info()).models : directGateway ? ['auto', ...directGateway.candidates.filter(r => r.enabled).map(r => 'route:' + r.id)] : [process.env.NOVA_MODEL], null, 2));
        return;
    }
    if (args._[0] === 'doctor') {
        let info;
        try {
            info = backend ? await backend.info() : { model: directGateway ? 'auto' : process.env.NOVA_MODEL, mode: args.direct ? 'direct' : 'not connected', routing: directGateway?.policy.mode };
        }
        catch (e) {
            info = { connectionError: e.message };
        }
        const localRoutes = directGateway?.candidates || (process.env.NOVA_MODEL_BASE && process.env.NOVA_MODEL ? [{ id: 'configured-model', role: 'general', priority: 50, enabled: true, config: { base: process.env.NOVA_MODEL_BASE, key: process.env.NOVA_MODEL_KEY || '', model: process.env.NOVA_MODEL, protocol: process.env.NOVA_MODEL_PROTOCOL || 'openai', system: '' } }] : []);
        log(JSON.stringify({ ...info, diagnostics: await (0, doctor_1.deviceDoctor)(localRoutes), project: root, execution: args.execution || 'docker', token: backend ? 'configured; not displayed' : 'not configured' }, null, 2));
        return;
    }
    const execution = args.execution || 'docker';
    if (!['docker', 'native', 'none'].includes(execution))
        throw new Error('Use --execution docker, native, or none');
    const maxSteps = Number(args['max-steps'] || 20);
    if (!Number.isInteger(maxSteps) || maxSteps < 2 || maxSteps > 40)
        throw new Error('--max-steps must be 2..40');
    if (args._[0] === 'sessions') {
        const sessions = await store.list();
        for (const s of sessions)
            log(s.id + ' · ' + s.title + ' · ' + new Date(s.updatedAt).toLocaleString());
        if (backend) {
            try {
                for (const s of (await backend.list(projectId)).sessions)
                    if (!sessions.some(local => local.id === s.id))
                        log(s.id + ' · ' + s.title + ' · cloud');
            }
            catch (e) {
                log('Cloud list: ' + e.message);
            }
        }
        return;
    }
    if (args._[0] === 'context-session') {
        if (!backend)
            throw new Error('A backend is required');
        const release = await store.lock();
        try {
            const saved = await backend.load(args._[1]);
            if (!saved?.session)
                throw new Error('Session not found');
            const copy = { id: crypto.randomUUID(), projectId, title: saved.session.title, messages: saved.session.messages, updatedAt: Date.now() };
            await store.save(copy);
            log('Imported conversation. Continue with nova resume ' + copy.id);
        }
        finally {
            await release();
        }
        return;
    }
    if (args._[0] === 'context') {
        const unlockContext = await store.lock();
        try {
            if (!backend)
                throw new Error('Context sync needs a configured backend');
            const { validateShared, sharedSnapshot } = await Promise.resolve().then(() => __importStar(require('../lib/agent/shared-context')));
            if (args._[1] === 'pull') {
                await store.saveShared(validateShared(await backend.context()));
                log('Shared context loaded outside your project. Local project profiles take priority.');
                return;
            }
            if (args._[1] === 'push') {
                if (!node_process_1.stdin.isTTY)
                    throw new Error('Context push requires interactive review');
                const rl = (0, promises_1.createInterface)({ input: node_process_1.stdin, output: node_process_1.stdout });
                try {
                    const shared = await store.shared();
                    const f = new files_1.ProjectFiles(root, store, async () => false);
                    const snapshot = sharedSnapshot((await f.records()).records, shared?.revision || 0);
                    log('Send these profiles/notes to your backend: ' + snapshot.records.map(r => r.name).join(', '));
                    if ((await rl.question('Approve shared context upload? [yes/no] ')).trim().toLowerCase() !== 'yes')
                        return;
                    await store.saveShared(validateShared(await backend.saveContext(snapshot)));
                    log('Shared context saved.');
                }
                finally {
                    rl.close();
                }
                return;
            }
            throw new Error('Use nova context pull or nova context push');
        }
        finally {
            await unlockContext();
        }
    }
    const release = await store.lock();
    let input;
    let active, closed = false;
    let plan = args.plan || !node_process_1.stdin.isTTY;
    const confirm = async (description, signal) => { if (!node_process_1.stdin.isTTY || !input)
        return false; signal.throwIfAborted(); log('\n' + description); return (await input.question('Approve this exact action? [yes/no] ', { signal })).trim().toLowerCase() === 'yes'; };
    const files = new files_1.ProjectFiles(root, store, confirm);
    const newSession = () => ({ id: crypto.randomUUID(), projectId, title: 'New coding session', messages: [], updatedAt: Date.now() });
    let session = newSession();
    let requested = args.resume || (args._[0] === 'resume' ? args._[1] : undefined);
    if (args.continue)
        requested = (await store.list())[0]?.id;
    try {
        if (requested) {
            session = await store.load(requested) || (await backend?.load(requested))?.session;
            if (!session)
                throw new Error('Session not found');
            if (session.projectId !== projectId)
                throw new Error('Session belongs to a different project. Use the same --project-id or choose its original project.');
        }
        if (node_process_1.stdin.isTTY) {
            input = (0, promises_1.createInterface)({ input: node_process_1.stdin, output: node_process_1.stdout });
            input.on('close', () => { closed = true; active?.abort(); });
            input.on('SIGINT', () => { if (active)
                active.abort();
            else
                input?.close(); });
        }
        const interrupt = () => { if (active)
            active.abort();
        else {
            closed = true;
            input?.close();
        } };
        process.on('SIGINT', interrupt);
        try {
            if (backend)
                await backend.info();
            log('Nova Code · ' + root + '\nSession ' + session.id + ' · ' + (plan ? 'plan mode' : 'reviewed edits') + ' · ' + execution + ' commands');
            if (execution === 'native')
                log('Native mode: approved commands run with your device permissions; this is not a sandbox.');
            let prompt = args.p || args.print || (args._[0] === 'resume' ? '' : args._.join(' '));
            if (!node_process_1.stdin.isTTY) {
                const context = await pipeInput();
                if (context)
                    prompt += (prompt ? '\n\nPIPED CONTEXT:\n' : '') + context;
                if (!prompt.trim())
                    throw new Error('Pass -p "your task" or pipe a prompt');
            }
            let retryNext = false;
            let once = !!(args.p || args.print) || !node_process_1.stdin.isTTY;
            while (!closed) {
                if (!prompt)
                    prompt = await input.question('You: ');
                if (!prompt.trim()) {
                    prompt = '';
                    continue;
                }
                if (prompt.startsWith('/')) {
                    const command = prompt.trim();
                    prompt = '';
                    if (['/exit', '/quit'].includes(command))
                        break;
                    if (command === '/help') {
                        log(HELP);
                        continue;
                    }
                    if (command === '/plan') {
                        plan = true;
                        log('Plan mode enabled.');
                        continue;
                    }
                    if (command === '/code') {
                        plan = false;
                        log('Reviewed edit mode enabled.');
                        continue;
                    }
                    if (command.startsWith('/model')) {
                        const selected = command.slice(6).trim();
                        if (!backend) {
                            if (selected) {
                                if (directGateway)
                                    process.env.NOVA_ROUTE = selected;
                                else
                                    process.env.NOVA_MODEL = selected;
                            }
                            log('Direct model: ' + (directGateway ? process.env.NOVA_ROUTE || 'auto' : process.env.NOVA_MODEL));
                        }
                        else {
                            const info = await backend.info();
                            if (selected) {
                                if (!info.models.includes(selected)) {
                                    log('Model is not allowed by this backend.');
                                    continue;
                                }
                                backend.model = selected;
                            }
                            log('Model: ' + (backend.model || info.model) + ' · available ' + info.models.join(', '));
                        }
                        continue;
                    }
                    if (command === '/new') {
                        session = newSession();
                        log('Session ' + session.id);
                        continue;
                    }
                    if (command === '/sessions') {
                        for (const s of await store.list())
                            log(s.id + ' · ' + s.title);
                        continue;
                    }
                    if (command === '/diff' || command === '/status') {
                        try {
                            log(JSON.stringify(await files.git(command === '/diff' ? 'diff' : 'status'), null, 2));
                        }
                        catch (e) {
                            log(e.message);
                        }
                        continue;
                    }
                    if (command === '/undo') {
                        try {
                            log(JSON.stringify(await files.undo(new AbortController().signal)));
                        }
                        catch (e) {
                            log(e.message);
                        }
                        continue;
                    }
                    if (command === '/retry') {
                        if (!session.run || session.run.status === 'completed') {
                            log('No interrupted task to retry.');
                            continue;
                        }
                        prompt = session.run.goal;
                        retryNext = true;
                    }
                    else {
                        log('Unknown slash command. Use /help.');
                        continue;
                    }
                }
                active = new AbortController();
                let lastEvent = '', preview = '';
                if (session.title === 'New coding session')
                    session.title = prompt.slice(0, 100);
                const goal = prompt;
                prompt = '';
                const retry = retryNext || !!requested && !!session.run && session.run.status !== 'completed' && session.run.goal === goal;
                retryNext = false;
                const output = await (0, runner_1.runCodingTurn)({ goal, session, files, store, backend, execution, plan, maxSteps, signal: active.signal, confirm, retry, update: run => { const e = run.events.at(-1); if (e && e.id !== lastEvent) {
                        lastEvent = e.id;
                        if (['action', 'plan', 'error'].includes(e.type))
                            log('[' + e.type + '] ' + e.title);
                    } }, preview: text => { if (node_process_1.stdin.isTTY && !args.json) {
                        if (!preview)
                            node_process_1.stdout.write('\nNova: ');
                        node_process_1.stdout.write((0, files_1.clean)(text.startsWith(preview) ? text.slice(preview.length) : '\n' + text));
                    } preview = text; } });
                active = undefined;
                requested = undefined;
                if (args.json)
                    node_process_1.stdout.write(JSON.stringify({ sessionId: session.id, status: output.result.status, answer: output.result.answer, modelCalls: output.modelCalls, tokens: output.tokens, syncError: output.syncError, events: output.result.events }) + '\n');
                else if (node_process_1.stdin.isTTY && preview === output.result.answer)
                    node_process_1.stdout.write('\n\n');
                else
                    log('\nNova: ' + output.result.answer + '\n');
                if (output.syncError)
                    log('Session is saved locally; cloud sync: ' + output.syncError);
                if (once) {
                    if (output.result.status !== 'completed')
                        process.exitCode = 1;
                    break;
                }
            }
        }
        finally {
            process.removeListener('SIGINT', interrupt);
        }
    }
    finally {
        input?.close();
        await release();
    }
}
if (require.main === module)
    void main().catch(e => { node_process_1.stderr.write((0, files_1.clean)(e.message) + '\n'); process.exitCode = 1; });
