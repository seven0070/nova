"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createBackend = createBackend;
exports.startBackend = startBackend;
const shared_context_1 = require("../../lib/agent/shared-context");
const router_1 = require("../router");
const gateway_1 = require("../../lib/agent/gateway");
const http_1 = require("../../lib/agent/http");
const node_http_1 = __importDefault(require("node:http"));
const node_crypto_1 = require("node:crypto");
const node_path_1 = __importDefault(require("node:path"));
const node_stream_1 = require("node:stream");
const promises_1 = require("node:stream/promises");
const model_client_1 = require("../../lib/agent/model-client");
const operations_1 = require("../../lib/agent/operations");
const store_1 = require("./store");
const database_1 = require("./database");
const queue_1 = require("./queue");
function createBackend(options) {
    for (const [label, token] of Object.entries(options.tokens))
        if (!/^[-_a-zA-Z0-9]{1,80}$/.test(label) || typeof token !== 'string' || token.length < 32)
            throw new Error('Backend tokens must be labeled and at least 32 characters');
    if (!Object.keys(options.tokens).length || !options.base || !options.model)
        throw new Error('Configure backend token, model base, and model');
    if (options.dailyCalls !== undefined && (!Number.isInteger(options.dailyCalls) || options.dailyCalls < 0 || options.dailyCalls > 100000))
        throw new Error('Invalid backend daily call limit');
    const endpoint = new URL(options.base);
    const local = ['localhost', '127.0.0.1', '[::1]'].includes(endpoint.hostname) && ['http:', 'https:'].includes(endpoint.protocol) && !endpoint.username && !endpoint.password;
    if (!local) {
        (0, http_1.publicHttps)(options.base);
        if (!options.key)
            throw new Error('Backend cloud provider needs NOVA_MODEL_KEY');
    }
    const database = new database_1.BackendDatabase(options.stateDir), queue = new queue_1.DecisionQueue(4, 16), models = options.gateway ? ['auto', ...options.gateway.candidates.filter(r => r.enabled).map(r => 'route:' + r.id)] : [...new Set([options.model, ...(options.models || [])])];
    const windows = new Map();
    let redemption = { at: Date.now(), count: 0 };
    const secrets = () => [options.key, ...Object.values(options.tokens), ...(options.gateway?.candidates.map(r => r.config.key) || [])];
    let metrics = database.get('_system', 'metrics') || {};
    const observe = async (event) => { const old = metrics[event.id] || { samples: 0, latencyMs: 0, failures: 0 }; metrics[event.id] = { samples: old.samples + (event.failed ? 0 : 1), latencyMs: event.failed ? old.latencyMs : old.samples ? old.latencyMs * .8 + event.latencyMs * .2 : event.latencyMs, failures: old.failures + (event.failed ? 1 : 0) }; database.put('_system', 'metrics', metrics); };
    const server = node_http_1.default.createServer(async (req, res) => {
        res.setHeader('Cache-Control', 'no-store');
        res.setHeader('X-Content-Type-Options', 'nosniff');
        const json = (status, value) => { res.writeHead(status, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(value)); };
        const abort = new AbortController();
        req.once('aborted', () => abort.abort());
        res.once('close', () => { if (!res.writableEnded)
            abort.abort(); });
        const timeout = setTimeout(() => abort.abort(new Error('Backend request timeout')), 120000);
        let release, meter, pending = false, who;
        const read = async () => { let bytes = 0; const chunks = []; for await (const part of req) {
            abort.signal.throwIfAborted();
            const chunk = Buffer.from(part);
            bytes += chunk.length;
            if (bytes > 1100000)
                throw Object.assign(new Error('Payload exceeds 1.1 MB'), { status: 413 });
            chunks.push(chunk);
        } return JSON.parse(Buffer.concat(chunks).toString()); };
        try {
            const url = new URL(req.url || '/', 'http://backend');
            if (req.headers.origin)
                throw Object.assign(new Error('Machine API does not accept browser-origin requests'), { status: 403 });
            if (req.method === 'POST' && url.pathname === '/v1/pair/redeem') {
                if (Date.now() - redemption.at > 60000)
                    redemption = { at: Date.now(), count: 0 };
                if (++redemption.count > 30)
                    throw Object.assign(new Error('Pairing rate limit reached'), { status: 429 });
                const input = await read();
                json(200, database.redeem(input.code));
                return;
            }
            const supplied = req.headers.authorization || '', raw = supplied.startsWith('Bearer ') ? supplied.slice(7) : '';
            let admin = false, scopes = [], deviceId;
            for (const [label, token] of Object.entries(options.tokens)) {
                const expected = 'Bearer ' + token;
                if (Buffer.byteLength(supplied) === Buffer.byteLength(expected) && (0, node_crypto_1.timingSafeEqual)(Buffer.from(supplied), Buffer.from(expected)) && !database.revoked(token)) {
                    who = label;
                    admin = true;
                    scopes = [...database_1.deviceScopes];
                }
            }
            if (!who && raw) {
                const device = database.authenticate(raw);
                if (device && options.tokens[device.parent] && !database.revoked(options.tokens[device.parent])) {
                    who = device.parent;
                    scopes = device.scopes;
                    deviceId = device.id;
                }
            }
            if (!who)
                throw Object.assign(new Error('Invalid or missing backend token'), { status: 401 });
            const clientId = (0, node_crypto_1.createHash)('sha256').update(who).digest('hex').slice(0, 32);
            const requireScope = (scope) => { if (!scopes.includes(scope))
                throw Object.assign(new Error('Device token does not allow ' + scope), { status: 403 }); };
            const redactValue = (v) => (0, operations_1.redact)(v, [...secrets(), raw]);
            const usage = () => { const day = new Date().toISOString().slice(0, 10), old = database.get(clientId, 'usage'); return old?.day === day ? old : { day, calls: 0, failures: 0 }; };
            if (req.method === 'GET' && url.pathname === '/v1/info') {
                json(200, { protocol: 'nova-cli/1', version: '0.12.0', model: options.gateway ? 'auto' : options.model, models, metrics, providerProtocol: options.protocol, capabilities: ['decisions', 'streaming', 'sessions', 'shared-context', 'scoped-devices', 'sqlite-storage', 'bounded-queue', ...(options.gateway ? ['model-router'] : [])], scopes, deviceId, admin, execution: 'device-only' });
                return;
            }
            if (url.pathname.startsWith('/v1/admin/')) {
                if (!admin)
                    throw Object.assign(new Error('Backend administrator token required'), { status: 403 });
                if (req.method === 'GET' && url.pathname === '/v1/admin/devices') {
                    json(200, { devices: database.devices(who) });
                    return;
                }
                if (req.method === 'POST' && url.pathname === '/v1/admin/pair') {
                    const input = await read();
                    json(200, database.pair(who, input.label, input.scopes || [...database_1.deviceScopes]));
                    return;
                }
                if (req.method === 'POST' && url.pathname === '/v1/admin/revoke') {
                    const input = await read();
                    database.revoke(who, String(input.id));
                    json(200, { revoked: true });
                    return;
                }
                if (req.method === 'GET' && url.pathname === '/v1/admin/health') {
                    json(200, { ...database.health(who), usage: usage(), dailyCalls: options.dailyCalls || 0, queue: queue.stats() });
                    return;
                }
                if (req.method === 'POST' && url.pathname === '/v1/admin/backup') {
                    database.audit(who, 'backup-requested');
                    json(200, database.backup());
                    return;
                }
            }
            if (req.method === 'POST' && url.pathname === '/v1/decision') {
                requireScope('decisions');
                meter = windows.get(who) || { at: Date.now(), count: 0, pending: 0 };
                if (Date.now() - meter.at > 60000) {
                    meter.at = Date.now();
                    meter.count = 0;
                }
                windows.set(who, meter);
                if (++meter.count > 60 || meter.pending >= 8)
                    throw Object.assign(new Error('Backend rate/concurrency limit reached'), { status: 429 });
                meter.pending++;
                pending = true;
                const input = await read();
                if (typeof input.system !== 'string' || input.system.length > 90000 || !Array.isArray(input.messages) || input.messages.length > 100 || input.messages.some((m) => !m || !['user', 'assistant'].includes(m.role) || typeof m.content !== 'string' || m.content.length > 90000))
                    throw new Error('Invalid agent context');
                if (input.model && !models.includes(input.model))
                    throw new Error('Model not allowed by this backend');
                release = await queue.acquire(abort.signal);
                abort.signal.throwIfAborted();
                const reserved = database.transaction(() => { const current = usage(); if (options.dailyCalls && current.calls >= options.dailyCalls)
                    throw Object.assign(new Error('Backend daily model call limit reached'), { status: 429 }); const next = { ...current, calls: current.calls + 1 }; database.put(clientId, 'usage', next); return next; });
                const started = Date.now();
                let failed = true;
                try {
                    const routed = options.gateway ? await (0, gateway_1.openGateway)(input.model && input.model !== 'auto' ? { ...options.gateway.policy, fallback: false } : options.gateway.policy, input.model && input.model !== 'auto' ? options.gateway.candidates.filter(r => 'route:' + r.id === input.model).map(r => ({ ...r, metrics: metrics[r.id] })) : options.gateway.candidates.map(r => ({ ...r, metrics: metrics[r.id] })), input.system, input.messages, abort.signal, true, input.stream === true, observe) : await (0, model_client_1.openModelResponse)({ base: options.base, key: options.key, model: input.model || options.model, protocol: options.protocol, system: input.system, fallbackModel: options.fallbackModel }, input.system, input.messages, abort.signal, true, input.stream === true);
                    const { response } = routed;
                    if ('routeId' in routed)
                        res.setHeader('X-Nova-Route', String(routed.routeId));
                    res.setHeader('X-Nova-Model', routed.model);
                    if (input.stream === true) {
                        res.writeHead(200, { 'Content-Type': 'text/event-stream' });
                        if (!response.body)
                            throw new Error('No model stream');
                        await (0, promises_1.pipeline)(node_stream_1.Readable.fromWeb(response.body), res);
                    }
                    else
                        json(200, await response.json());
                    failed = false;
                }
                finally {
                    const latest = usage();
                    if (latest.day === reserved.day)
                        database.put(clientId, 'usage', { ...latest, failures: latest.failures + (failed ? 1 : 0), lastLatencyMs: Date.now() - started });
                    database.audit(who, failed ? 'decision-failed' : 'decision-completed', { deviceId, latencyMs: Date.now() - started });
                }
                return;
            }
            if (url.pathname === '/v1/context') {
                if (req.method === 'GET') {
                    requireScope('context:read');
                    json(200, database.get(clientId, 'context') || { revision: 0, records: [], updatedAt: 0 });
                    return;
                }
                if (req.method === 'PUT') {
                    requireScope('context:write');
                    const input = (0, shared_context_1.validateShared)(await read());
                    const next = database.transaction(() => { const old = database.get(clientId, 'context') || { revision: 0, records: [], updatedAt: 0 }; if (input.revision !== old.revision)
                        throw Object.assign(new Error('Shared context changed. Pull and review before pushing.'), { status: 409 }); const value = { ...redactValue(input), revision: old.revision + 1, updatedAt: Date.now() }; database.put(clientId, 'context', value); return value; });
                    json(200, next);
                    return;
                }
            }
            if (req.method === 'GET' && url.pathname === '/v1/sessions') {
                requireScope('sessions:read');
                const project = url.searchParams.get('projectId');
                const sessions = database.list(clientId, 'session:').filter(s => !project || s.projectId === project).map(s => ({ id: s.id, title: s.title, projectId: s.projectId, updatedAt: s.updatedAt, messages: [], revision: s.revision }));
                json(200, { sessions: sessions.sort((a, b) => b.updatedAt - a.updatedAt) });
                return;
            }
            const match = /^\/v1\/sessions\/([-_a-zA-Z0-9]{1,80})$/.exec(url.pathname);
            if (match) {
                const key = 'session:' + match[1];
                if (req.method === 'GET') {
                    requireScope('sessions:read');
                    const session = database.get(clientId, key);
                    json(session ? 200 : 404, session ? { session } : { error: 'Session not found' });
                    return;
                }
                if (req.method === 'PUT') {
                    requireScope('sessions:write');
                    const input = await read(), session = (0, store_1.validateSession)(input.session);
                    if (session.id !== match[1])
                        throw new Error('Session ID mismatch');
                    const revision = database.transaction(() => { const old = database.get(clientId, key); if (!old && database.list(clientId, 'session:').length >= 200)
                        throw new Error('Cloud session limit reached'); if (old && old.revision !== input.revision)
                        throw Object.assign(new Error('Cloud session changed. Fork before overwriting it.'), { status: 409 }); const revision = (old?.revision || 0) + 1; database.put(clientId, key, { ...redactValue(session), revision, updatedAt: Date.now() }); return revision; });
                    json(200, { revision });
                    return;
                }
            }
            json(404, { error: 'Unknown backend endpoint' });
        }
        catch (e) {
            if (!res.headersSent)
                json(e.status || 400, { error: (0, operations_1.redact)(e.message, [...secrets(), req.headers.authorization?.slice(7) || '']) });
            else
                res.destroy();
        }
        finally {
            clearTimeout(timeout);
            release?.();
            if (pending && meter)
                meter.pending--;
        }
    });
    server.requestTimeout = 120000;
    server.headersTimeout = 15000;
    server.once('close', () => database.close());
    return server;
}
async function startBackend() { const gateway = await (0, router_1.loadDeviceGateway)(), primary = gateway?.candidates.find(r => r.enabled)?.config; const options = { gateway, tokens: process.env.NOVA_BACKEND_TOKENS ? JSON.parse(process.env.NOVA_BACKEND_TOKENS) : { personal: process.env.NOVA_BACKEND_TOKEN || '' }, base: process.env.NOVA_MODEL_BASE || primary?.base || '', key: process.env.NOVA_MODEL_KEY || primary?.key || '', model: process.env.NOVA_MODEL || primary?.model || '', protocol: process.env.NOVA_MODEL_PROTOCOL || 'openai', fallbackModel: process.env.NOVA_FALLBACK_MODEL, models: (process.env.NOVA_BACKEND_MODELS || '').split(',').map(s => s.trim()).filter(Boolean), stateDir: node_path_1.default.resolve(process.env.NOVA_BACKEND_STATE_DIR || '.nova-backend'), host: process.env.NOVA_BACKEND_HOST || '127.0.0.1', port: Number(process.env.NOVA_BACKEND_PORT || 4319), dailyCalls: Number(process.env.NOVA_BACKEND_DAILY_CALLS || 0) }; const server = createBackend(options); await new Promise((resolve, reject) => { server.once('error', reject); server.listen(options.port, options.host, () => { server.removeListener('error', reject); resolve(); }); }); console.log('Nova backend ready at ' + options.host + ':' + server.address().port + ' · HTTPS is required for remote clients'); const stop = () => { server.close(); server.closeAllConnections(); }; process.once('SIGINT', stop); process.once('SIGTERM', stop); return server; }
