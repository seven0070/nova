"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BackendDatabase = exports.deviceScopes = void 0;
const node_sqlite_1 = require("node:sqlite");
const node_fs_1 = require("node:fs");
const node_path_1 = __importDefault(require("node:path"));
const node_crypto_1 = require("node:crypto");
const shared_context_1 = require("../../lib/agent/shared-context");
const store_1 = require("./store");
const hash = (s) => (0, node_crypto_1.createHash)('sha256').update(s).digest('hex');
exports.deviceScopes = ['decisions', 'context:read', 'context:write', 'sessions:read', 'sessions:write'];
class BackendDatabase {
    directory;
    db;
    file;
    constructor(directory) {
        this.directory = directory;
        (0, node_fs_1.mkdirSync)(directory, { recursive: true, mode: 0o700 });
        this.file = node_path_1.default.join(directory, 'nova.sqlite');
        this.db = new node_sqlite_1.DatabaseSync(this.file);
        (0, node_fs_1.chmodSync)(this.file, 0o600);
        this.db.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA busy_timeout=5000');
        const version = Number(this.db.prepare('PRAGMA user_version').get().user_version);
        if (version > 1) {
            this.db.close();
            throw new Error('Backend database is newer than this Nova version');
        }
        if (version === 0) {
            this.db.exec(`BEGIN IMMEDIATE;CREATE TABLE records(scope TEXT NOT NULL,key TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY(scope,key));CREATE TABLE devices(id TEXT PRIMARY KEY,parent TEXT NOT NULL,label TEXT NOT NULL,hash TEXT UNIQUE NOT NULL,scopes TEXT NOT NULL,created INTEGER NOT NULL,revoked INTEGER);CREATE TABLE pairings(hash TEXT PRIMARY KEY,parent TEXT NOT NULL,label TEXT NOT NULL,scopes TEXT NOT NULL,expires INTEGER NOT NULL);CREATE TABLE revoked(hash TEXT PRIMARY KEY);CREATE TABLE audit(id INTEGER PRIMARY KEY,event TEXT NOT NULL,at INTEGER NOT NULL,owner TEXT NOT NULL,detail TEXT NOT NULL);PRAGMA user_version=1;COMMIT;`);
        }
        try {
            this.migrateLegacy();
        }
        catch (e) {
            this.db.close();
            throw e;
        }
    }
    get(scope, key) { const row = this.db.prepare('SELECT value FROM records WHERE scope=? AND key=?').get(scope, key); return row ? JSON.parse(row.value) : undefined; }
    put(scope, key, value) { this.db.prepare('INSERT INTO records VALUES(?,?,?) ON CONFLICT(scope,key) DO UPDATE SET value=excluded.value').run(scope, key, JSON.stringify(value)); }
    list(scope, prefix) { return this.db.prepare('SELECT value FROM records WHERE scope=? AND substr(key,1,?)=?').all(scope, prefix.length, prefix).map((r) => JSON.parse(r.value)); }
    transaction(fn) { this.db.exec('BEGIN IMMEDIATE'); try {
        const result = fn();
        this.db.exec('COMMIT');
        return result;
    }
    catch (e) {
        this.db.exec('ROLLBACK');
        throw e;
    } }
    audit(owner, event, detail = {}) { this.db.prepare('INSERT INTO audit(event,at,owner,detail) VALUES(?,?,?,?)').run(event, Date.now(), owner, JSON.stringify(detail)); this.db.exec('DELETE FROM audit WHERE id <= (SELECT max(id)-2000 FROM audit)'); }
    health(owner) { return { storage: 'sqlite', schemaVersion: 1, audit: this.db.prepare('SELECT event,at,detail FROM audit WHERE owner=? ORDER BY id DESC LIMIT 30').all(owner).map((r) => ({ ...r, detail: JSON.parse(r.detail) })) }; }
    migrateLegacy() {
        if (this.get('_system', 'legacy-imported'))
            return;
        const imports = [];
        const read = (file) => { if ((0, node_fs_1.lstatSync)(file).isSymbolicLink() || (0, node_fs_1.lstatSync)(file).size > 1100000)
            throw new Error('Unsafe or oversized legacy backend state'); return JSON.parse((0, node_fs_1.readFileSync)(file, 'utf8')); };
        for (const scope of (0, node_fs_1.readdirSync)(this.directory).filter(n => /^[a-f0-9]{32}$/.test(n))) {
            const folder = node_path_1.default.join(this.directory, scope);
            if ((0, node_fs_1.lstatSync)(folder).isSymbolicLink() || !(0, node_fs_1.lstatSync)(folder).isDirectory())
                throw new Error('Invalid legacy backend directory');
            for (const name of (0, node_fs_1.readdirSync)(folder).filter(n => /^[-_a-zA-Z0-9]{1,80}\.json$/.test(n)).slice(0, 201)) {
                const value = (0, store_1.validateSession)(read(node_path_1.default.join(folder, name)));
                if (name !== value.id + '.json')
                    throw new Error('Legacy session ID mismatch');
                imports.push({ scope, key: 'session:' + value.id, value });
            }
            const context = node_path_1.default.join(folder, 'context', 'state.json');
            if ((0, node_fs_1.existsSync)(context)) {
                if ((0, node_fs_1.lstatSync)(node_path_1.default.dirname(context)).isSymbolicLink())
                    throw new Error('Invalid context directory');
                imports.push({ scope, key: 'context', value: (0, shared_context_1.validateShared)(read(context)) });
            }
        }
        const metrics = node_path_1.default.join(this.directory, 'router', 'metrics.json');
        if ((0, node_fs_1.existsSync)(metrics)) {
            if ((0, node_fs_1.lstatSync)(node_path_1.default.dirname(metrics)).isSymbolicLink())
                throw new Error('Invalid metrics directory');
            imports.push({ scope: '_system', key: 'metrics', value: read(metrics) });
        }
        this.transaction(() => { for (const item of imports)
            if (!this.get(item.scope, item.key))
                this.put(item.scope, item.key, item.value); this.put('_system', 'legacy-imported', { at: Date.now(), records: imports.length }); });
    }
    pair(parent, label, scopes) { if (!/^[-_a-zA-Z0-9 ]{1,80}$/.test(label) || !Array.isArray(scopes) || !scopes.length || scopes.some(s => !exports.deviceScopes.includes(s)))
        throw new Error('Invalid device label or scopes'); return this.transaction(() => { this.db.prepare('DELETE FROM pairings WHERE expires<?').run(Date.now()); const count = this.db.prepare('SELECT count(*) AS n FROM pairings WHERE parent=?').get(parent).n; if (count >= 10)
        throw new Error('Ten active pairing codes already exist'); const code = (0, node_crypto_1.randomBytes)(18).toString('base64url'), expiresAt = Date.now() + 300000; this.db.prepare('INSERT INTO pairings VALUES(?,?,?,?,?)').run(hash(code), parent, label, JSON.stringify([...new Set(scopes)]), expiresAt); this.audit(parent, 'pairing-created', { label, expiresAt }); return { code, expiresAt, scopes }; }); }
    redeem(code) { if (typeof code !== 'string' || code.length > 100)
        throw new Error('Invalid pairing code'); return this.transaction(() => { const row = this.db.prepare('SELECT * FROM pairings WHERE hash=?').get(hash(code)); if (!row || row.expires < Date.now())
        throw new Error('Invalid or expired pairing code'); const count = this.db.prepare('SELECT count(*) AS n FROM devices WHERE parent=? AND revoked IS NULL').get(row.parent).n; if (count >= 50)
        throw new Error('Fifty active devices already exist'); const token = (0, node_crypto_1.randomBytes)(32).toString('base64url'), id = crypto.randomUUID(); this.db.prepare('DELETE FROM pairings WHERE hash=?').run(hash(code)); this.db.prepare('INSERT INTO devices(id,parent,label,hash,scopes,created) VALUES(?,?,?,?,?,?)').run(id, row.parent, row.label, hash(token), row.scopes, Date.now()); this.audit(row.parent, 'device-paired', { id, label: row.label }); return { token, id, label: row.label, scopes: JSON.parse(row.scopes) }; }); }
    authenticate(token) { const row = this.db.prepare('SELECT * FROM devices WHERE hash=? AND revoked IS NULL').get(hash(token)); return row ? { id: row.id, parent: row.parent, scopes: JSON.parse(row.scopes) } : undefined; }
    revoked(token) { return !!this.db.prepare('SELECT hash FROM revoked WHERE hash=?').get(hash(token)); }
    devices(parent) { return this.db.prepare('SELECT id,label,scopes,created,revoked FROM devices WHERE parent=? ORDER BY created DESC').all(parent).map((r) => ({ ...r, scopes: JSON.parse(r.scopes) })); }
    revoke(parent, id) { const found = this.db.prepare('SELECT id FROM devices WHERE id=? AND parent=?').get(id, parent); if (!found)
        throw new Error('Device not found'); this.db.prepare('UPDATE devices SET revoked=? WHERE id=? AND parent=?').run(Date.now(), id, parent); this.audit(parent, 'device-revoked', { id }); }
    backup() { const folder = node_path_1.default.join(this.directory, 'backups'); (0, node_fs_1.mkdirSync)(folder, { recursive: true, mode: 0o700 }); if ((0, node_fs_1.readdirSync)(folder).filter(n => /^nova-.*\.sqlite$/.test(n)).length >= 10)
        throw new Error('Ten backend snapshots exist; archive them before creating another'); const file = node_path_1.default.join(folder, 'nova-' + Date.now() + '-' + (0, node_crypto_1.randomBytes)(4).toString('hex') + '.sqlite'); this.db.prepare('VACUUM INTO ?').run(file); (0, node_fs_1.chmodSync)(file, 0o600); return { filename: node_path_1.default.basename(file), createdAt: Date.now(), schemaVersion: 1 }; }
    close() { this.db.close(); }
}
exports.BackendDatabase = BackendDatabase;
