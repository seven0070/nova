"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BackendClient = void 0;
const stream_1 = require("../../lib/agent/stream");
class BackendClient {
    config;
    model;
    constructor(config) {
        this.config = config;
    }
    async request(route, options = {}, signal) { const response = await fetch(this.config.backend + route, { ...options, redirect: 'error', headers: { Authorization: 'Bearer ' + this.config.token, 'Content-Type': 'application/json', ...options.headers }, signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(110000)]) : AbortSignal.timeout(15000) }); if (!response.ok) {
        let error = 'Backend HTTP ' + response.status;
        try {
            const data = await response.json();
            error = data.error || error;
        }
        catch { }
        throw Object.assign(new Error(error), { status: response.status });
    } return response; }
    async info() { const data = await (await this.request('/v1/info')).json(); if (data.protocol !== 'nova-cli/1')
        throw new Error('This URL does not implement the Nova CLI backend protocol'); return data; }
    async decision(system, messages, signal, preview) { const response = await this.request('/v1/decision', { method: 'POST', body: JSON.stringify({ system, messages, stream: true, model: this.model }) }, signal); let usage; const text = await (0, stream_1.readModelStream)(response, signal, preview, value => { usage = { ...usage, ...value }; }); return { text, usage }; }
    async context() { return (await (await this.request('/v1/context')).json()); }
    async saveContext(context) { return (await (await this.request('/v1/context', { method: 'PUT', body: JSON.stringify(context) })).json()); }
    async list(projectId) { return (await (await this.request('/v1/sessions?projectId=' + encodeURIComponent(projectId))).json()); }
    async load(id) { return (await (await this.request('/v1/sessions/' + encodeURIComponent(id))).json()); }
    async save(session) { const data = await (await this.request('/v1/sessions/' + encodeURIComponent(session.id), { method: 'PUT', body: JSON.stringify({ session, revision: session.revision }) })).json(); return data.revision; }
}
exports.BackendClient = BackendClient;
