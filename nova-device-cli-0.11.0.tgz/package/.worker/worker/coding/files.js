"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProjectFiles = void 0;
exports.allowedPath = allowedPath;
exports.clean = clean;
exports.projectRoot = projectRoot;
exports.nativeCommand = nativeCommand;
const promises_1 = require("node:fs/promises");
const node_path_1 = __importDefault(require("node:path"));
const node_child_process_1 = require("node:child_process");
const node_util_1 = require("node:util");
const diff_1 = require("diff");
const records_1 = require("../../lib/agent/records");
const operations_1 = require("../../lib/agent/operations");
const store_1 = require("./store");
const exec = (0, node_util_1.promisify)(node_child_process_1.execFile);
const excluded = new Set(['.git', '.nova', '.nova-cli', '.ssh', 'node_modules', '.next', 'dist', 'build', 'coverage', '__pycache__', '.venv', 'venv']);
function allowedPath(name) { (0, records_1.safePath)(name); if (name.split('/').some(p => excluded.has(p) || p.startsWith('.env') || ['.npmrc', '.netrc', '.pypirc', 'credentials.json', 'vault.key'].includes(p)) || /\.(pem|key|p12|pfx)$/.test(name))
    throw new Error('Reserved or credential path'); return name; }
function clean(text) { return text.replace(/\x1b\][^\x07]*(?:\x07|\x1b\\)/g, '').replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, '').replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/g, ''); }
class ProjectFiles {
    root;
    store;
    confirm;
    constructor(root, store, confirm) {
        this.root = root;
        this.store = store;
        this.confirm = confirm;
    }
    edits = [];
    async location(name, parents = false) { allowedPath(name); let current = this.root; const parts = name.split('/'); for (let i = 0; i < parts.length; i++) {
        current = node_path_1.default.join(current, parts[i]);
        try {
            const stat = await (0, promises_1.lstat)(current);
            if (stat.isSymbolicLink())
                throw new Error('Symlink paths are not allowed');
            if (i < parts.length - 1 && !stat.isDirectory())
                throw new Error('Parent is not a directory');
        }
        catch (e) {
            if (e.code !== 'ENOENT')
                throw e;
            if (i < parts.length - 1) {
                if (!parents)
                    throw e;
            }
        }
    } return current; }
    async read(name) { const file = await this.location(name), stat = await (0, promises_1.lstat)(file); if (!stat.isFile() || stat.size > 200000)
        throw new Error('Read a text file under 200 KB'); const bytes = await (0, promises_1.readFile)(file); if (bytes.includes(0))
        throw new Error('Binary files are not supported'); return bytes.toString('utf8'); }
    async list() { const names = []; let truncated = false; async function scan(dir, prefix = '', depth = 0) { if (depth > 12 || names.length >= 2000) {
        truncated = true;
        return;
    } for (const entry of await (0, promises_1.readdir)(dir, { withFileTypes: true })) {
        const name = prefix + entry.name;
        try {
            allowedPath(name);
        }
        catch {
            continue;
        }
        if (entry.isSymbolicLink())
            continue;
        if (entry.isDirectory())
            await scan(node_path_1.default.join(dir, entry.name), name + '/', depth + 1);
        else if (entry.isFile())
            names.push(name);
        if (names.length >= 2000) {
            truncated = true;
            break;
        }
    } } await scan(this.root); return { names, truncated }; }
    async records() { const list = await this.list(); const files = []; let budget = 5000000; for (const name of list.names) {
        try {
            const content = await this.read(name);
            if (content.length > budget)
                continue;
            budget -= content.length;
            files.push({ id: 'file:' + name, kind: 'file', name, content, updatedAt: Date.now() });
        }
        catch { }
    } const all = [...files, ...await this.store.records(), ...((await this.store.shared())?.records || [])]; return { records: all.filter((r, i) => all.findIndex(x => x.id === r.id) === i), truncated: list.truncated || budget <= 0 }; }
    async write(name, content, signal) { if (content.length > 200000)
        throw new Error('File exceeds 200 KB'); const file = await this.location(name, true); let before = null, mode = 0o644; try {
        before = await this.read(name);
        mode = (await (0, promises_1.lstat)(file)).mode & 0o777;
    }
    catch (e) {
        if (e.code !== 'ENOENT')
            throw e;
    } if (before === content)
        return; const patch = (0, diff_1.createPatch)(name, before || '', content); const preview = patch.length > 20000 ? patch.slice(0, 20000) + '\n[Preview truncated; ' + content.length + ' new characters. SHA ' + await (0, operations_1.fingerprint)(content) + ']' : patch; if (!await this.confirm('Write ' + name + '\n' + clean(preview), signal))
        throw new Error('File change denied'); signal.throwIfAborted(); let latest = null; try {
        latest = await this.read(name);
    }
    catch (e) {
        if (e.code !== 'ENOENT')
            throw e;
    } if (latest !== before)
        throw new Error('File changed during review. Read it again before editing'); await (0, promises_1.mkdir)(node_path_1.default.dirname(file), { recursive: true }); await this.location(name); const edit = { id: crypto.randomUUID(), path: name, before, after: content, time: Date.now() }; await (0, store_1.atomicJson)(node_path_1.default.join(this.store.folder, 'edits', edit.id + '.json'), edit); const tmp = file + '.nova-' + crypto.randomUUID() + '.tmp'; try {
        await (0, promises_1.writeFile)(tmp, content, { mode });
        await (0, promises_1.rename)(tmp, file);
        await (0, promises_1.chmod)(file, mode);
    }
    finally {
        await (0, promises_1.unlink)(tmp).catch(() => { });
    } this.edits.push(edit); }
    async remove(name, signal, approved = false) { const before = await this.read(name); if (!approved && !await this.confirm('Delete ' + name + '\n' + clean(before.slice(0, 12000)), signal))
        throw new Error('Deletion denied'); signal.throwIfAborted(); const edit = { id: crypto.randomUUID(), path: name, before, after: null, time: Date.now() }; await (0, store_1.atomicJson)(node_path_1.default.join(this.store.folder, 'edits', edit.id + '.json'), edit); await (0, promises_1.unlink)(await this.location(name)); this.edits.push(edit); }
    async undo(signal) { let edit = this.edits.at(-1); if (!edit) {
        let names = [];
        try {
            names = await (0, promises_1.readdir)(node_path_1.default.join(this.store.folder, 'edits'));
        }
        catch { }
        const values = [];
        for (const name of names.filter(n => n.endsWith('.json'))) {
            const item = JSON.parse(await (0, promises_1.readFile)(node_path_1.default.join(this.store.folder, 'edits', name), 'utf8'));
            if (!item.undone)
                values.push({ ...item, id: name.slice(0, -5) });
        }
        edit = values.sort((a, b) => b.time - a.time)[0];
    } if (!edit)
        throw new Error('No recorded edit to undo'); let current = null; try {
        current = await this.read(edit.path);
    }
    catch (e) {
        if (e.code !== 'ENOENT')
            throw e;
    } if (current !== edit.after)
        throw new Error('File changed after Nova’s edit; undo refused to preserve your changes'); if (!await this.confirm('Undo the latest edit to ' + edit.path + '?', signal))
        throw new Error('Undo denied'); let latest = null; try {
        latest = await this.read(edit.path);
    }
    catch (e) {
        if (e.code !== 'ENOENT')
            throw e;
    } if (latest !== current)
        throw new Error('File changed during undo review'); if (edit.before === null)
        await (0, promises_1.unlink)(await this.location(edit.path));
    else {
        await this.location(edit.path, true);
        await (0, promises_1.writeFile)(await this.location(edit.path), edit.before, 'utf8');
    } if (edit.id)
        await (0, store_1.atomicJson)(node_path_1.default.join(this.store.folder, 'edits', edit.id + '.json'), { ...edit, undone: true }); this.edits.pop(); return { restored: edit.path }; }
    async git(action) { const args = ['--no-optional-locks', '-c', 'core.fsmonitor=false', '-c', 'core.hooksPath=/dev/null']; if (action === 'status') {
        const { stdout } = await exec('git', [...args, 'status', '--porcelain=v1', '--untracked-files=normal'], { cwd: this.root, maxBuffer: 200000, timeout: 10000 });
        return { status: stdout.slice(0, 30000) };
    } const { stdout: names } = await exec('git', [...args, 'diff', '--no-ext-diff', '--name-only'], { cwd: this.root, maxBuffer: 200000, timeout: 10000 }); const paths = names.trim().split('\n').filter(Boolean).filter(p => { try {
        allowedPath(p);
        return true;
    }
    catch {
        return false;
    } }); if (!paths.length)
        return { diff: 'No eligible tracked changes.' }; const { stdout } = await exec('git', [...args, '--literal-pathspecs', 'diff', '--no-ext-diff', '--no-textconv', '--', ...paths.slice(0, 100)], { cwd: this.root, maxBuffer: 500000, timeout: 10000 }); return { diff: stdout.slice(0, 50000), truncated: stdout.length > 50000 }; }
    async execute(call, signal) { signal.throwIfAborted(); if (call.name === 'read_file')
        return { path: call.args.path, content: await this.read(String(call.args.path)) }; if (call.name === 'list_files') {
        const list = await this.list();
        return { files: list.names.map(name => ({ path: name })), truncated: list.truncated };
    } if (call.name === 'verify_file') {
        const text = await this.read(String(call.args.path));
        const terms = call.args.contains || [];
        if (!Array.isArray(terms) || terms.some(t => typeof t !== 'string'))
            throw new Error('contains must be a text array');
        const missing = terms.filter(t => !text.includes(t));
        let validJson = true;
        if (call.args.json === true) {
            try {
                JSON.parse(text);
            }
            catch {
                validJson = false;
            }
        }
        const passed = !missing.length && validJson && text.length >= Number(call.args.minChars || 0);
        return { passed, missing, validJson, sha256: await (0, operations_1.fingerprint)(text), ...(passed ? {} : { error: 'Verification failed' }) };
    } if (call.name === 'search_files') {
        const query = String(call.args.query || '');
        if (!query || query.length > 500)
            throw new Error('Supply a search query under 500 characters');
        const list = await this.list(), matches = [];
        let budget = 5000000;
        for (const name of list.names) {
            try {
                const text = await this.read(name);
                budget -= text.length;
                if (budget < 0)
                    break;
                for (const [i, line] of text.split('\n').entries())
                    if (line.toLowerCase().includes(query.toLowerCase())) {
                        matches.push({ path: name, line: i + 1, text: line.slice(0, 800) });
                        if (matches.length >= 100)
                            return { matches, truncated: true };
                    }
            }
            catch { }
        }
        return { matches, truncated: list.truncated || budget < 0 };
    } if (call.name === 'apply_patch') {
        const name = String(call.args.path), old = call.args.old_text, replacement = call.args.new_text;
        if (typeof old !== 'string' || !old || typeof replacement !== 'string')
            throw new Error('Supply nonempty old_text and new_text');
        const before = await this.read(name);
        const index = before.indexOf(old);
        if (index < 0 || before.indexOf(old, index + 1) >= 0)
            throw new Error('Patch must match exactly once. Read a larger unique context');
        await this.write(name, before.slice(0, index) + replacement + before.slice(index + old.length), signal);
        return { patched: name };
    } if (call.name === 'git_status')
        return this.git('status'); if (call.name === 'git_diff')
        return this.git('diff'); throw new Error('Unknown local coding tool'); }
}
exports.ProjectFiles = ProjectFiles;
async function projectRoot(value) { const root = await (0, promises_1.realpath)(value); if (!(await (0, promises_1.lstat)(root)).isDirectory() || root === node_path_1.default.parse(root).root || root === process.env.HOME)
    throw new Error('Choose a project directory, not your home/system root'); return root; }
async function nativeCommand(command, cwd, signal) { signal.throwIfAborted(); if (!command.trim() || command.length > 8000)
    throw new Error('Command exceeds limit'); const env = { NODE_ENV: 'production' }; for (const key of ['PATH', 'HOME', 'USER', 'TMPDIR', 'TEMP', 'SystemRoot', 'COMSPEC'])
    if (process.env[key])
        env[key] = process.env[key]; const shell = process.platform === 'win32' ? (process.env.COMSPEC || 'cmd.exe') : '/bin/sh'; const args = process.platform === 'win32' ? ['/d', '/s', '/c', command] : ['-c', command]; return new Promise(resolve => { const child = (0, node_child_process_1.spawn)(shell, args, { cwd, env, stdio: ['ignore', 'pipe', 'pipe'], detached: process.platform !== 'win32' }); let stdout = '', stderr = '', timedOut = false; child.stdout.on('data', data => { stdout = (stdout + data.toString()).slice(0, 32000); }); child.stderr.on('data', data => { stderr = (stderr + data.toString()).slice(0, 32000); }); const stop = () => { if (process.platform !== 'win32' && child.pid) {
    try {
        process.kill(-child.pid, 'SIGKILL');
    }
    catch {
        child.kill('SIGKILL');
    }
}
else
    child.kill('SIGKILL'); }; const timer = setTimeout(() => { timedOut = true; stop(); }, 60000); signal.addEventListener('abort', stop, { once: true }); child.once('error', e => { stderr = e.message; }); child.once('close', code => { clearTimeout(timer); signal.removeEventListener('abort', stop); resolve({ stdout, stderr, exitCode: code, timedOut }); }); }); }
