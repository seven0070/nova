"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.localModels = localModels;
exports.writeBackendSetup = writeBackendSetup;
exports.connectSetup = connectSetup;
exports.setupWizard = setupWizard;
exports.verifyBackend = verifyBackend;
const promises_1 = require("node:readline/promises");
const node_stream_1 = require("node:stream");
const node_process_1 = require("node:process");
const promises_2 = require("node:fs/promises");
const node_crypto_1 = require("node:crypto");
const node_path_1 = __importDefault(require("node:path"));
const config_1 = require("./coding/config");
const remote_1 = require("./coding/remote");
const engine_1 = require("../lib/agent/engine");
const gateway_1 = require("../lib/agent/gateway");
const http_1 = require("../lib/agent/http");
const env = (value) => { if (/[\r\n\0"\\]/.test(value))
    throw new Error('Configuration values cannot contain line breaks, quotes or backslashes'); return '"' + value + '"'; };
async function localModels(base) { base = (0, config_1.backendUrl)(base); if (!(0, gateway_1.isLocal)(base))
    throw new Error('Local setup accepts localhost endpoints only'); const response = await fetch(base + '/models', { redirect: 'error', signal: AbortSignal.timeout(8000) }); if (!response.ok)
    throw new Error('Local inference server HTTP ' + response.status); const data = await response.json(); if (!Array.isArray(data.data))
    throw new Error('Expected an OpenAI-compatible model list'); return data.data.map((m) => m?.id).filter((id) => typeof id === 'string' && id.length > 0 && id.length <= 200).slice(0, 100); }
async function writeBackendSetup(directory, input) { const base = (0, config_1.backendUrl)(input.base); if (!(0, gateway_1.isLocal)(base))
    (0, http_1.publicHttps)(base); if (!input.model.trim() || input.model.length > 200 || !['openai', 'anthropic'].includes(input.protocol) || !Number.isInteger(input.port) || input.port < 1024 || input.port > 65535)
    throw new Error('Supply a model ID, protocol and port 1024–65535'); if (!(0, gateway_1.isLocal)(base) && !input.key.trim())
    throw new Error('Cloud inference needs a provider key'); const token = (0, node_crypto_1.randomBytes)(32).toString('hex'); directory = node_path_1.default.resolve(directory); const entries = { NOVA_BACKEND_HOST: '127.0.0.1', NOVA_BACKEND_PORT: String(input.port), NOVA_BACKEND_STATE_DIR: node_path_1.default.join(directory, 'state'), NOVA_BACKEND_TOKEN: token, NOVA_MODEL_BASE: base, NOVA_MODEL_KEY: input.key, NOVA_MODEL: input.model, NOVA_MODEL_PROTOCOL: input.protocol }; const content = Object.entries(entries).map(([k, v]) => k + '=' + env(v)).join('\n') + '\n'; await (0, promises_2.mkdir)(directory, { recursive: true, mode: 0o700 }); const file = node_path_1.default.join(directory, 'backend.env'); await (0, promises_2.writeFile)(file, content, { flag: 'wx', mode: 0o600 }); return { file, url: 'http://127.0.0.1:' + input.port, model: input.model }; }
async function connectSetup(base, token) { base = (0, config_1.backendUrl)(base); if (token.length < 32 || /[\r\n\0]/.test(token))
    throw new Error('Use the issued token of at least 32 characters'); const config = { backend: base, token }; const info = await new remote_1.BackendClient(config).info(); await (0, config_1.saveConfig)(config); return { backend: base, model: info.model, sharedContext: info.capabilities?.includes('shared-context') === true }; }
async function ask(prompt, secret = false) { const output = new node_stream_1.Writable({ write(chunk, _encoding, done) { if (!secret)
        node_process_1.stdout.write(chunk); done(); } }); Object.assign(output, { isTTY: true }); const rl = (0, promises_1.createInterface)({ input: node_process_1.stdin, output, terminal: true }); if (secret)
    node_process_1.stdout.write(prompt); try {
    return (await rl.question(secret ? '' : prompt)).trim();
}
finally {
    rl.close();
    if (secret)
        node_process_1.stdout.write('\n');
} }
async function setupWizard(kind, root = process.cwd()) {
    if (!node_process_1.stdin.isTTY || !node_process_1.stdout.isTTY)
        throw new Error('Setup requires an interactive terminal; keys are entered without echo');
    if (!['backend', 'local', 'connect'].includes(kind))
        throw new Error('Use nova setup backend, nova setup local, or nova setup connect');
    if (kind === 'connect') {
        const base = await ask('Backend HTTPS URL (or localhost): '), token = await ask('Issued backend token (hidden): ', true);
        const info = await connectSetup(base, token);
        node_process_1.stdout.write('Connected to ' + info.backend + ' · ' + info.model + ' · shared context ' + (info.sharedContext ? 'available' : 'requires backend upgrade') + '\n');
        return;
    }
    let base = await ask(kind === 'local' ? 'Local API base [http://localhost:11434/v1]: ' : 'Provider API base [https://api.openai.com/v1]: ');
    base = base || (kind === 'local' ? 'http://localhost:11434/v1' : 'https://api.openai.com/v1');
    let model, key = '', protocol = 'openai';
    if (kind === 'local') {
        let models;
        try {
            models = await localModels(base);
        }
        catch (e) {
            throw new Error(e.message + ' · Start Ollama or LM Studio, install/load a model, then run setup again. Guide: docs/CONNECT_EVERYTHING.md');
        }
        if (!models.length)
            throw new Error('No installed/loaded models. Load one in your inference server first.');
        node_process_1.stdout.write(models.map((id, i) => (i + 1) + '. ' + id).join('\n') + '\n');
        const choice = Number(await ask('Choose model number: '));
        if (!Number.isInteger(choice) || choice < 1 || choice > models.length)
            throw new Error('Choose a listed model');
        model = models[choice - 1];
    }
    else {
        const selected = await ask('Protocol [openai/anthropic; default openai]: ');
        if (selected && selected !== 'openai' && selected !== 'anthropic')
            throw new Error('Unsupported protocol');
        protocol = (selected || 'openai');
        model = await ask('Model ID available to your account: ');
        if (!(0, gateway_1.isLocal)(base))
            key = await ask('Provider API key (hidden): ', true);
    }
    const folder = node_path_1.default.join(root, '.nova-setup');
    node_process_1.stdout.write('Create ' + node_path_1.default.join(folder, 'backend.env') + ' for ' + base + ' · ' + model + '?\n');
    if ((await ask('Create this configuration? [yes/no] ')).toLowerCase() !== 'yes')
        return;
    const config = await writeBackendSetup(folder, { base, model, key, protocol, port: 4319 });
    node_process_1.stdout.write('Configuration saved with owner-only permissions. Start the backend:\n' + JSON.stringify(process.execPath) + ' --env-file=' + JSON.stringify(config.file) + ' ' + JSON.stringify(node_path_1.default.resolve(__dirname, '../../bin/nova.cjs')) + ' backend\nThen run nova setup connect and enter ' + config.url + '. Retrieve the generated token from your private environment file; never post it in chat.\nFor HTTPS hosting and background services, see docs/BACKEND.md and docs/CONNECT_EVERYTHING.md.\n');
}
async function verifyBackend(config) { const client = new remote_1.BackendClient(config); const info = await client.info(), started = Date.now(); const reply = await client.decision('You are testing Nova connectivity. Return only a JSON final decision: {"type":"final","answer":"Nova connection verified"}. No tools or actions.', [{ role: 'user', content: 'Verify the model connection.' }], new AbortController().signal, () => { }); const result = (0, engine_1.parseAction)(reply.text); if (result.type !== 'final' || !result.answer.trim())
    throw new Error('The selected model did not produce Nova’s required final decision format'); return { backend: config.backend, model: info.model, latencyMs: Date.now() - started, structuredDecision: true, sharedContext: info.capabilities?.includes('shared-context') === true }; }
