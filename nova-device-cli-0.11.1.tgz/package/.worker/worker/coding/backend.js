"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createBackend = createBackend;
exports.startBackend = startBackend;
const shared_context_1 = require("../../lib/agent/shared-context");
const router_1 = require("../router");
const gateway_1 = require("../../lib/agent/gateway");
const http_1 = require("../../lib/agent/http");
const node_http_1 = __importDefault(require("node:http"));
const node_crypto_1 = require("node:crypto");
const promises_1 = require("node:fs/promises");
const node_path_1 = __importDefault(require("node:path"));
const node_stream_1 = require("node:stream");
const promises_2 = require("node:stream/promises");
const model_client_1 = require("../../lib/agent/model-client");
const operations_1 = require("../../lib/agent/operations");
const store_1 = require("./store");
function createBackend(options) {
    for (const [label, token] of Object.entries(options.tokens))
        if (!/^[-_a-zA-Z0-9]{1,80}$/.test(label) || typeof token !== 'string' || token.length < 32)
            throw new Error('Backend tokens must be labeled and at least 32 characters');
    if (!Object.keys(options.tokens).length || !options.base || !options.model)
        throw new Error('Configure backend token, model base, and model');
    const endpoint = new URL(options.base);
    const local = ['localhost', '127.0.0.1', '[::1]'].includes(endpoint.hostname) && ['http:', 'https:'].includes(endpoint.protocol) && !endpoint.username && !endpoint.password;
    if (!local) {
        (0, http_1.publicHttps)(options.base);
        if (!options.key)
            throw new Error('Backend cloud provider needs NOVA_MODEL_KEY');
    }
    const models = options.gateway ? ['auto', ...options.gateway.candidates.filter(r => r.enabled).map(r => 'route:' + r.id)] : [...new Set([options.model, ...(options.models || [])])];
    const windows = new Map();
    const locks = new Map();
    const metricsFile = node_path_1.default.join(options.stateDir, 'router', 'metrics.json');
    let metrics = {};
    const metricsReady = (0, promises_1.readFile)(metricsFile, 'utf8').then(raw => { metrics = JSON.parse(raw); }).catch(e => { if (e.code !== 'ENOENT')
        throw e; });
    let metricsWrites = Promise.resolve();
    const observe = async (event) => { const old = metrics[event.id] || { samples: 0, latencyMs: 0, failures: 0 }; metrics[event.id] = { samples: old.samples + (event.failed ? 0 : 1), latencyMs: event.failed ? old.latencyMs : old.samples ? old.latencyMs * .8 + event.latencyMs * .2 : event.latencyMs, failures: old.failures + (event.failed ? 1 : 0) }; metricsWrites = metricsWrites.catch(() => { }).then(() => (0, store_1.atomicJson)(metricsFile, metrics)); await metricsWrites; };
    return node_http_1.default.createServer(async (req, res) => {
        res.setHeader('Cache-Control', 'no-store');
        res.setHeader('X-Content-Type-Options', 'nosniff');
        const json = (status, value) => { res.writeHead(status, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(value)); };
        let who;
        const supplied = req.headers.authorization || '';
        for (const [label, token] of Object.entries(options.tokens)) {
            const expected = 'Bearer ' + token;
            if (Buffer.byteLength(supplied) === Buffer.byteLength(expected) && (0, node_crypto_1.timingSafeEqual)(Buffer.from(supplied), Buffer.from(expected)))
                who = label;
        }
        if (!who) {
            json(401, { error: 'Invalid or missing backend token' });
            return;
        }
        if (req.headers.origin) {
            json(403, { error: 'Machine API does not accept browser-origin requests' });
            return;
        }
        const clientId = (0, node_crypto_1.createHash)('sha256').update(who).digest('hex').slice(0, 32), folder = node_path_1.default.join(options.stateDir, clientId);
        const abort = new AbortController();
        req.once('aborted', () => abort.abort());
        res.once('close', () => { if (!res.writableEnded)
            abort.abort(); });
        let active = false;
        let meter = windows.get(who) || { at: Date.now(), count: 0, active: 0 };
        if (Date.now() - meter.at > 60000) {
            meter.at = Date.now();
            meter.count = 0;
        }
        windows.set(who, meter);
        try {
            await metricsReady;
            const url = new URL(req.url || '/', 'http://backend');
            if (req.method === 'GET' && url.pathname === '/v1/info') {
                json(200, { protocol: 'nova-cli/1', version: '0.11.1', model: options.gateway ? 'auto' : options.model, models, metrics, providerProtocol: options.protocol, capabilities: ['decisions', 'streaming', 'sessions', 'shared-context', ...(options.gateway ? ['model-router'] : [])], execution: 'device-only' });
                return;
            }
            const read = async () => { let bytes = 0; const chunks = []; for await (const part of req) {
                const chunk = Buffer.from(part);
                bytes += chunk.length;
                if (bytes > 1100000)
                    throw Object.assign(new Error('Payload exceeds 1.1 MB'), { status: 413 });
                chunks.push(chunk);
            } return JSON.parse(Buffer.concat(chunks).toString()); };
            if (req.method === 'POST' && url.pathname === '/v1/decision') {
                if (++meter.count > 60 || meter.active >= 4)
                    throw Object.assign(new Error('Backend rate/concurrency limit reached'), { status: 429 });
                meter.active++;
                active = true;
                const input = await read();
                if (typeof input.system !== 'string' || input.system.length > 90000 || !Array.isArray(input.messages) || input.messages.length > 100 || input.messages.some((m) => !m || !['user', 'assistant'].includes(m.role) || typeof m.content !== 'string' || m.content.length > 90000))
                    throw new Error('Invalid agent context');
                if (input.model && !models.includes(input.model))
                    throw new Error('Model not allowed by this backend');
                const routed = options.gateway ? await (0, gateway_1.openGateway)(input.model && input.model !== 'auto' ? { ...options.gateway.policy, fallback: false } : options.gateway.policy, input.model && input.model !== 'auto' ? options.gateway.candidates.filter(r => 'route:' + r.id === input.model).map(r => ({ ...r, metrics: metrics[r.id] })) : options.gateway.candidates.map(r => ({ ...r, metrics: metrics[r.id] })), input.system, input.messages, abort.signal, true, input.stream === true, observe) : await (0, model_client_1.openModelResponse)({ base: options.base, key: options.key, model: input.model || options.model, protocol: options.protocol, system: input.system, fallbackModel: options.fallbackModel }, input.system, input.messages, abort.signal, true, input.stream === true);
                const { response } = routed;
                if ('routeId' in routed)
                    res.setHeader('X-Nova-Route', String(routed.routeId));
                res.setHeader('X-Nova-Model', routed.model);
                if (input.stream === true) {
                    res.writeHead(200, { 'Content-Type': 'text/event-stream' });
                    if (!response.body)
                        throw new Error('No model stream');
                    await (0, promises_2.pipeline)(node_stream_1.Readable.fromWeb(response.body), res);
                }
                else {
                    json(200, await response.json());
                }
                return;
            }
            if (url.pathname === '/v1/context') {
                const file = node_path_1.default.join(folder, 'context', 'state.json');
                if (req.method === 'GET') {
                    let context = { revision: 0, records: [], updatedAt: 0 };
                    try {
                        context = (0, shared_context_1.validateShared)(JSON.parse(await (0, promises_1.readFile)(file, 'utf8')));
                    }
                    catch (e) {
                        if (e.code !== 'ENOENT')
                            throw e;
                    }
                    json(200, context);
                    return;
                }
                if (req.method === 'PUT') {
                    const input = (0, shared_context_1.validateShared)(await read());
                    const previous = locks.get(file) || Promise.resolve();
                    const operation = previous.catch(() => { }).then(async () => { let old = { revision: 0, records: [], updatedAt: 0 }; try {
                        old = (0, shared_context_1.validateShared)(JSON.parse(await (0, promises_1.readFile)(file, 'utf8')));
                    }
                    catch (e) {
                        if (e.code !== 'ENOENT')
                            throw e;
                    } if (input.revision !== old.revision)
                        throw Object.assign(new Error('Shared context changed. Pull and review before pushing.'), { status: 409 }); const next = { ...(0, operations_1.redact)(input, [options.key, ...Object.values(options.tokens), ...(options.gateway?.candidates.map(r => r.config.key) || [])]), revision: old.revision + 1, updatedAt: Date.now() }; await (0, store_1.atomicJson)(file, next); return next; });
                    locks.set(file, operation);
                    try {
                        json(200, await operation);
                    }
                    finally {
                        if (locks.get(file) === operation)
                            locks.delete(file);
                    }
                    return;
                }
            }
            if (req.method === 'GET' && url.pathname === '/v1/sessions') {
                let names = [];
                try {
                    names = await (0, promises_1.readdir)(folder);
                }
                catch (e) {
                    if (e.code !== 'ENOENT')
                        throw e;
                }
                const sessions = [];
                for (const name of names.filter(n => n.endsWith('.json')).slice(0, 200)) {
                    const session = JSON.parse(await (0, promises_1.readFile)(node_path_1.default.join(folder, name), 'utf8'));
                    if (!url.searchParams.get('projectId') || session.projectId === url.searchParams.get('projectId'))
                        sessions.push({ id: session.id, title: session.title, projectId: session.projectId, updatedAt: session.updatedAt, messages: [], revision: session.revision });
                }
                json(200, { sessions: sessions.sort((a, b) => b.updatedAt - a.updatedAt) });
                return;
            }
            const match = /^\/v1\/sessions\/([-_a-zA-Z0-9]{1,80})$/.exec(url.pathname);
            if (match) {
                const file = node_path_1.default.join(folder, match[1] + '.json');
                if (req.method === 'GET') {
                    try {
                        json(200, { session: JSON.parse(await (0, promises_1.readFile)(file, 'utf8')) });
                    }
                    catch (e) {
                        if (e.code === 'ENOENT') {
                            json(404, { error: 'Session not found' });
                            return;
                        }
                        throw e;
                    }
                    return;
                }
                if (req.method === 'PUT') {
                    const input = await read(), session = (0, store_1.validateSession)(input.session);
                    if (session.id !== match[1])
                        throw new Error('Session ID mismatch');
                    const previous = locks.get(file) || Promise.resolve();
                    const operation = previous.catch(() => { }).then(async () => { let old; try {
                        old = JSON.parse(await (0, promises_1.readFile)(file, 'utf8'));
                    }
                    catch (e) {
                        if (e.code !== 'ENOENT')
                            throw e;
                    } if (!old) {
                        let existing = [];
                        try {
                            existing = await (0, promises_1.readdir)(folder);
                        }
                        catch (e) {
                            if (e.code !== 'ENOENT')
                                throw e;
                        }
                        if (existing.filter(name => name.endsWith('.json')).length >= 200)
                            throw new Error('Cloud session limit reached');
                    } if (old && old.revision !== input.revision)
                        throw Object.assign(new Error('Cloud session changed. Fork before overwriting it.'), { status: 409 }); const revision = (old?.revision || 0) + 1; await (0, store_1.atomicJson)(file, { ...(0, operations_1.redact)(session, [options.key, ...Object.values(options.tokens), ...(options.gateway?.candidates.map(r => r.config.key) || [])]), revision, updatedAt: Date.now() }); return revision; });
                    locks.set(file, operation);
                    try {
                        json(200, { revision: await operation });
                    }
                    finally {
                        if (locks.get(file) === operation)
                            locks.delete(file);
                    }
                    return;
                }
            }
            json(404, { error: 'Unknown backend endpoint' });
        }
        catch (e) {
            if (!res.headersSent) {
                const status = e.status || 400;
                json(status, { error: (0, operations_1.redact)(e.message, [options.key, ...Object.values(options.tokens), ...(options.gateway?.candidates.map(r => r.config.key) || [])]) });
            }
            else
                res.destroy();
        }
        finally {
            if (active)
                meter.active--;
        }
    });
}
async function startBackend() { const gateway = await (0, router_1.loadDeviceGateway)(), primary = gateway?.candidates.find(r => r.enabled)?.config; const options = { gateway, tokens: process.env.NOVA_BACKEND_TOKENS ? JSON.parse(process.env.NOVA_BACKEND_TOKENS) : { personal: process.env.NOVA_BACKEND_TOKEN || '' }, base: process.env.NOVA_MODEL_BASE || primary?.base || '', key: process.env.NOVA_MODEL_KEY || primary?.key || '', model: process.env.NOVA_MODEL || primary?.model || '', protocol: process.env.NOVA_MODEL_PROTOCOL || 'openai', fallbackModel: process.env.NOVA_FALLBACK_MODEL, models: (process.env.NOVA_BACKEND_MODELS || '').split(',').map(s => s.trim()).filter(Boolean), stateDir: node_path_1.default.resolve(process.env.NOVA_BACKEND_STATE_DIR || '.nova-backend'), host: process.env.NOVA_BACKEND_HOST || '127.0.0.1', port: Number(process.env.NOVA_BACKEND_PORT || 4319) }; const server = createBackend(options); await new Promise((resolve, reject) => { server.once('error', reject); server.listen(options.port, options.host, () => { server.removeListener('error', reject); resolve(); }); }); console.log('Nova backend ready at ' + options.host + ':' + server.address().port + ' · HTTPS is required for remote clients'); const stop = () => { server.close(); server.closeAllConnections(); }; process.once('SIGINT', stop); process.once('SIGTERM', stop); return server; }
