"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionPublisher = void 0;
/** Serial checkpoints own cloud revisions; no approvals or local execution rights cross devices. */
class SessionPublisher {
    client;
    session;
    control;
    lease = '';
    pending = Promise.resolve();
    timer;
    error;
    constructor(client, session, control) {
        this.client = client;
        this.session = session;
        this.control = control;
    }
    async start() { const value = await this.client.claim(this.session); this.lease = value.leaseId; this.session.revision = value.revision; this.timer = setInterval(() => { void this.publish().catch(() => { }); }, 4000); this.timer.unref(); }
    publish(status = 'running') { const operation = this.pending.then(async () => { if (this.error)
        throw new Error(this.error); const result = await this.client.checkpoint(structuredClone(this.session), this.lease, status); this.session.revision = result.revision; for (const item of result.controls)
        this.control(item); }); this.pending = operation.catch(e => { this.error = e.message; this.control({ type: 'stop' }); }); return operation; }
    stop() { if (this.timer)
        clearInterval(this.timer); this.timer = undefined; }
    async finish(status) { this.stop(); await this.pending; if (this.error)
        throw new Error(this.error); return this.publish(['completed', 'failed'].includes(status) ? status : 'paused'); }
}
exports.SessionPublisher = SessionPublisher;
