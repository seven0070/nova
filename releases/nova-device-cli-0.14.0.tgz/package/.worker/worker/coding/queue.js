"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DecisionQueue = void 0;
class DecisionQueue {
    concurrency;
    capacity;
    active = 0;
    waiting = [];
    constructor(concurrency = 4, capacity = 16) {
        this.concurrency = concurrency;
        this.capacity = capacity;
    }
    stats() { return { active: this.active, waiting: this.waiting.length, capacity: this.capacity }; }
    async acquire(signal) { signal.throwIfAborted(); if (this.active < this.concurrency) {
        this.active++;
        return this.release();
    } if (this.waiting.length >= this.capacity)
        throw Object.assign(new Error('Backend queue full; retry shortly'), { status: 429 }); return new Promise((resolve, reject) => { const entry = { resolve, reject, signal, stop: () => { this.waiting = this.waiting.filter(e => e !== entry); reject(signal.reason); } }; signal.addEventListener('abort', entry.stop, { once: true }); this.waiting.push(entry); }); }
    release() { let done = false; return () => { if (done)
        return; done = true; this.active--; while (this.waiting.length) {
        const next = this.waiting.shift();
        next.signal.removeEventListener('abort', next.stop);
        if (next.signal.aborted) {
            next.reject(next.signal.reason);
            continue;
        }
        this.active++;
        next.resolve(this.release());
        break;
    } }; }
}
exports.DecisionQueue = DecisionQueue;
