"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runCodingTurn = runCodingTurn;
const plugins_1 = require("./plugins");
const publisher_1 = require("./publisher");
const shared_context_1 = require("../../lib/agent/shared-context");
const core_1 = require("../../lib/agent/core");
const operations_1 = require("../../lib/agent/operations");
const terminal_1 = require("../../lib/server/terminal");
const http_1 = require("../../lib/agent/http");
const provider_1 = require("../provider");
const files_1 = require("./files");
async function runCodingTurn(options) {
    const sessionAbort = new AbortController(), signal = AbortSignal.any([options.signal, sessionAbort.signal]);
    let publisher, liveSupported = false;
    let calls = 0, tokens = 0, pending = Promise.resolve(), storageError;
    const session = options.session;
    let contextWarning;
    if (options.backend) {
        try {
            const info = await options.backend.info();
            liveSupported = info.capabilities?.includes('live-sessions') && (!info.scopes || info.scopes.includes('sessions:write'));
            if (info.capabilities?.includes('shared-context')) {
                const remote = (0, shared_context_1.validateShared)(await options.backend.context()), previous = await options.store.shared(), notes = await options.store.records();
                for (const n of notes) {
                    const old = previous?.records.find(r => r.id === n.id), newer = remote.records.find(r => r.id === n.id);
                    if (old && n.content !== old.content && newer && newer.content !== old.content)
                        throw new Error('Shared note conflict; review context before pushing');
                }
                await options.store.replaceNotes(notes.filter(n => !previous?.records.some(r => r.id === n.id && r.content === n.content)));
                await options.store.saveShared(remote);
            }
        }
        catch (e) {
            contextWarning = 'Shared context: ' + e.message;
        }
    }
    const secrets = [options.backend?.config.token || '', process.env.NOVA_MODEL_KEY || ''];
    const readOnly = ['list_files', 'read_file', 'verify_file', 'search_files', 'git_status', 'git_diff', 'search_history', 'list_connections', 'mcp_list', 'search_memory', 'search_documents', 'calculate', 'fetch_url', 'delegate'];
    const tools = options.plan ? readOnly : [...readOnly, 'write_file', 'delete_file', 'apply_patch', 'save_memory', 'save_skill', 'run_skill', 'mcp_call', ...(options.execution === 'none' ? [] : ['run_command'])];
    let instructions = 'You are Nova Code, a coding agent attached to a local project. Use paths relative to this project. Read relevant files, propose minimal diffs, apply reviewed edits, run relevant checks when approved, and report evidence. Credentials/system paths are unavailable to file tools. Commands require approval. Never claim tests passed without observed command results. ' + (options.plan ? 'READ-ONLY PLAN MODE. Inspect and explain a concrete plan; do not change files or execute commands.' : 'Every file write shows a review diff and needs human approval.');
    for (const name of ['NOVA.md', 'AGENTS.md']) {
        try {
            instructions += '\nPROJECT GUIDANCE ' + name + ':\n' + (await options.files.read(name)).slice(0, 12000);
        }
        catch { }
    }
    const run = options.retry && session.run ? { ...session.run, status: 'running', answer: '', transcript: [...session.run.transcript, { role: 'user', content: 'The user explicitly resumed this task. Verify interrupted changes before repeating operations.' }] } : { id: crypto.randomUUID(), goal: options.goal, status: 'running', plan: [], events: [], transcript: [{ role: 'user', content: options.goal + '\n\nRECENT CONVERSATION (context only):\n' + session.messages.slice(-16).map(m => m.role + ': ' + m.content.slice(0, 7000)).join('\n') }], answer: '', updatedAt: Date.now() };
    if (options.backend && liveSupported) {
        publisher = new publisher_1.SessionPublisher(options.backend, session, item => { if (item.type === 'stop')
            sessionAbort.abort(new Error('Session stopped or disconnected by its shared controller'));
        else if (item.text) {
            run.transcript.push({ role: 'user', content: 'USER STEERING AT CHECKPOINT: ' + item.text });
        } });
        await publisher.start();
    }
    const plugins = new plugins_1.DevicePlugins();
    const pluginSecrets = (await plugins.list()).map(p => p.tokenEnv ? process.env[p.tokenEnv] || '' : '');
    secrets.push(...pluginSecrets);
    const core = new core_1.NovaCore({ service: async (call, abort) => call.name === 'search_history' ? { matches: await options.store.search(String(call.args.query)), note: 'Historical context is not new authorization.' } : plugins.execute(call, abort), coding: (call, signal) => options.files.execute(call, signal), listRecords: () => options.files.records(), saveRecord: async (record, toolSignal) => { if (record.kind === 'file')
            await options.files.write(record.name, record.content, toolSignal || signal);
        else
            await options.store.note(record); return record; }, deleteRecord: async (id) => { if (!id.startsWith('file:'))
            throw new Error('Only project files may be deleted'); await options.files.remove(id.slice(5), signal, true); }, fetchUrl: http_1.readUrl, command: async (command, signal) => options.execution === 'native' ? (0, files_1.nativeCommand)(command, options.files.root, signal) : (0, terminal_1.runCommand)(command, options.files.root, signal), approve: (call, signal) => options.confirm('Approve ' + call.name + '\n' + JSON.stringify(call.args, null, 2), signal), audit: entry => options.store.audit(entry), model: async (system, messages, signal) => { if (++calls > Math.min(40, options.maxSteps * 2) || tokens >= 100000)
            throw new Error('CLI response budget reached'); const reply = options.backend ? await options.backend.decision(system, messages, signal, options.preview || (() => { })) : await (0, provider_1.model)(system, messages, signal); tokens += Number(reply.usage?.total_tokens || Number(reply.usage?.input_tokens || 0) + Number(reply.usage?.output_tokens || 0) || Math.ceil((system.length + messages.reduce((n, m) => n + m.content.length, 0) + reply.text.length) / 4)); return reply; } }, { runtime: 'local', terminalEnabled: !options.plan && options.execution !== 'none', codingEnabled: true }, { level: options.plan ? 'read' : 'operator', allowedTools: tools }, secrets);
    try {
        const result = await core.run({ run, persona: instructions, maxSteps: options.maxSteps, signal, persist: false, update: next => { session.run = (0, operations_1.redact)(next, secrets); session.updatedAt = Date.now(); pending = pending.then(() => options.store.save({ ...session })).catch(e => { storageError = e; }); options.update?.(next); } });
        await pending;
        if (storageError) {
            await publisher?.finish('paused').catch(() => { });
            throw new Error('Could not save local checkpoint: ' + storageError.message);
        }
        session.run = (0, operations_1.redact)(result, secrets);
        if (result.status === 'completed') {
            session.messages = [...session.messages, { role: 'user', content: options.goal.slice(0, 90000) }, { role: 'assistant', content: result.answer.slice(0, 90000) }].slice(-300);
        }
        session.updatedAt = Date.now();
        await options.store.save(session);
        let syncError = contextWarning;
        if (publisher) {
            try {
                await publisher.finish(result.status);
                await options.store.save(session);
            }
            catch (e) {
                syncError = e.message;
            }
        }
        if (options.backend) {
            try {
                const shared = await options.store.shared();
                if (shared) {
                    const notes = await options.store.records();
                    const bundle = (0, shared_context_1.sharedSnapshot)([...notes, ...shared.records.filter(r => !notes.some(n => n.id === r.id))], shared.revision);
                    if (JSON.stringify(bundle.records) !== JSON.stringify(shared.records))
                        await options.store.saveShared((0, shared_context_1.validateShared)(await options.backend.saveContext(bundle)));
                }
            }
            catch (e) {
                syncError = e.message;
            }
            try {
                if (!publisher)
                    session.revision = await options.backend.save(session);
                await options.store.save(session);
            }
            catch (e) {
                syncError = [syncError, e.message].filter(Boolean).join('; ');
            }
        }
        return { result, modelCalls: calls, tokens, syncError };
    }
    finally {
        publisher?.stop();
    }
}
