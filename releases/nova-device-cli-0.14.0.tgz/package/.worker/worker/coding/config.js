"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.cliHome = void 0;
exports.backendUrl = backendUrl;
exports.loadConfig = loadConfig;
exports.saveConfig = saveConfig;
exports.remoteConfig = remoteConfig;
const node_os_1 = require("node:os");
const node_path_1 = __importDefault(require("node:path"));
const promises_1 = require("node:fs/promises");
const cliHome = () => node_path_1.default.resolve(process.env.NOVA_CLI_HOME || node_path_1.default.join((0, node_os_1.homedir)(), '.nova-cli'));
exports.cliHome = cliHome;
function backendUrl(value) { const url = new URL(value); const local = ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname); if ((url.protocol !== 'https:' && !(local && url.protocol === 'http:')) || url.username || url.password || url.search || url.hash)
    throw new Error('Backend must use HTTPS, or HTTP on localhost, without URL credentials/query/fragment'); return url.toString().replace(/\/+$/, ''); }
async function loadConfig() { try {
    return JSON.parse(await (0, promises_1.readFile)(node_path_1.default.join((0, exports.cliHome)(), 'config.json'), 'utf8'));
}
catch (e) {
    if (e.code === 'ENOENT')
        return {};
    throw new Error('CLI configuration cannot be read; fix or remove config.json');
} }
async function saveConfig(config) { await (0, promises_1.mkdir)((0, exports.cliHome)(), { recursive: true, mode: 0o700 }); const file = node_path_1.default.join((0, exports.cliHome)(), 'config.json'), tmp = file + '.' + crypto.randomUUID() + '.tmp'; await (0, promises_1.writeFile)(tmp, JSON.stringify(config), { mode: 0o600 }); await (0, promises_1.rename)(tmp, file); await (0, promises_1.chmod)(file, 0o600); }
async function remoteConfig(url) { const saved = await loadConfig(); const backend = backendUrl(url || process.env.NOVA_BACKEND_URL || saved.backend || ''); const token = process.env.NOVA_BACKEND_TOKEN || (saved.backend === backend ? saved.token : ''); if (!token || token.length < 32)
    throw new Error('Connect with nova connect URL and a NOVA_BACKEND_TOKEN of at least 32 characters'); return { backend, token }; }
