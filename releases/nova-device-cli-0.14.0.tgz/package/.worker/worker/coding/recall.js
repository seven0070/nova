"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceRecall = void 0;
const node_sqlite_1 = require("node:sqlite");
const node_fs_1 = require("node:fs");
const node_path_1 = __importDefault(require("node:path"));
/** Per-project FTS index: original JSON sessions remain the source of truth. */
class DeviceRecall {
    db;
    constructor(folder) {
        (0, node_fs_1.mkdirSync)(folder, { recursive: true, mode: 0o700 });
        const file = node_path_1.default.join(folder, "recall.sqlite");
        this.db = new node_sqlite_1.DatabaseSync(file);
        (0, node_fs_1.chmodSync)(file, 0o600);
        this.db.exec('PRAGMA busy_timeout=5000;CREATE VIRTUAL TABLE IF NOT EXISTS history USING fts5(session UNINDEXED,role UNINDEXED,content,updated UNINDEXED,tokenize="unicode61");');
    }
    index(session) {
        this.db.exec("BEGIN IMMEDIATE");
        try {
            this.db.prepare("DELETE FROM history WHERE session=?").run(session.id);
            const insert = this.db.prepare("INSERT INTO history(session,role,content,updated) VALUES(?,?,?,?)");
            for (const m of session.messages)
                insert.run(session.id, m.role, m.content, session.updatedAt);
            this.db.exec("COMMIT");
        }
        catch (e) {
            this.db.exec("ROLLBACK");
            throw e;
        }
    }
    search(query) {
        if (typeof query !== "string" || query.length > 500)
            throw new Error("Search query must be under 500 characters");
        const words = query.match(/[\p{L}\p{N}_-]+/gu)?.slice(0, 20) || [];
        if (!words.length)
            return [];
        const match = words
            .map((w) => '"' + w.replace(/"/g, '""') + '"')
            .join(" OR ");
        return this.db
            .prepare("SELECT session AS sessionId,role,snippet(history,2,'','', ' … ',48) AS excerpt,updated AS updatedAt FROM history WHERE history MATCH ? ORDER BY bm25(history),updated DESC LIMIT 20")
            .all(match);
    }
    close() {
        this.db.close();
    }
}
exports.DeviceRecall = DeviceRecall;
