"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DevicePlugins = void 0;
exports.validatePlugin = validatePlugin;
const promises_1 = require("node:fs/promises");
const node_path_1 = __importDefault(require("node:path"));
const config_1 = require("./config");
const store_1 = require("./store");
const mcp_client_1 = require("../../lib/agent/mcp-client");
function validatePlugin(v) {
    if (!v ||
        !/^[-a-z0-9]{1,60}$/.test(v.id) ||
        typeof v.name !== "string" ||
        !v.name.trim() ||
        v.name.length > 100 ||
        !Array.isArray(v.tools) ||
        v.tools.length > 80 ||
        v.tools.some((t) => typeof t !== "string" || !/^[-_.a-zA-Z0-9]{1,100}$/.test(t)) ||
        (v.tokenEnv !== undefined && !/^NOVA_MCP_[A-Z0-9_]{1,80}$/.test(v.tokenEnv)))
        throw new Error("Invalid MCP plugin manifest");
    const u = new URL(v.base), local = ["localhost", "127.0.0.1", "[::1]"].includes(u.hostname);
    if ((u.protocol !== "https:" && !(local && u.protocol === "http:")) ||
        u.username ||
        u.password ||
        u.hash ||
        u.search)
        throw new Error("MCP requires HTTPS or loopback HTTP without URL secrets");
    return {
        id: v.id,
        name: v.name,
        base: u.href,
        tokenEnv: v.tokenEnv,
        tools: [...new Set(v.tools)],
    };
}
class DevicePlugins {
    get folder() {
        return node_path_1.default.join((0, config_1.cliHome)(), "plugins");
    }
    async inspect(file) {
        const stat = await (0, promises_1.lstat)(file);
        if (!stat.isFile() || stat.isSymbolicLink() || stat.size > 30000)
            throw new Error("Select a regular plugin JSON file under 30 KB");
        return validatePlugin(JSON.parse(await (0, promises_1.readFile)(file, "utf8")));
    }
    async install(plugin) {
        const value = validatePlugin(plugin);
        await (0, store_1.atomicJson)(node_path_1.default.join(this.folder, value.id + ".json"), value);
        return value;
    }
    async list() {
        let files = [];
        try {
            files = await (0, promises_1.readdir)(this.folder);
        }
        catch (e) {
            if (e.code !== "ENOENT")
                throw e;
        }
        return Promise.all(files
            .filter((n) => /^[-a-z0-9]+\.json$/.test(n))
            .map(async (n) => validatePlugin(JSON.parse(await (0, promises_1.readFile)(node_path_1.default.join(this.folder, n), "utf8")))));
    }
    async remove(id) {
        if (!/^[-a-z0-9]{1,60}$/.test(id))
            throw new Error("Invalid plugin ID");
        await (0, promises_1.unlink)(node_path_1.default.join(this.folder, id + ".json"));
    }
    async execute(call, signal) {
        const plugins = await this.list();
        if (call.name === "list_connections")
            return {
                connections: plugins.map((p) => ({
                    id: p.id,
                    name: p.name,
                    kind: "mcp",
                    tools: p.tools,
                })),
            };
        const plugin = plugins.find((p) => p.id === call.args.connectionId);
        if (!plugin)
            throw new Error("Unknown installed plugin");
        const key = plugin.tokenEnv ? process.env[plugin.tokenEnv] : undefined;
        if (plugin.tokenEnv && !key)
            throw new Error("Configure the plugin token environment variable");
        return (0, mcp_client_1.callMCP)({ ...plugin, key }, call.name === "mcp_list" ? undefined : String(call.args.tool), call.args.arguments || {}, signal);
    }
}
exports.DevicePlugins = DevicePlugins;
