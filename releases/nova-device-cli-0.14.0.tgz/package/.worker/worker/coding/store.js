"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceStore = void 0;
exports.validateSession = validateSession;
exports.atomicJson = atomicJson;
const recall_1 = require("./recall");
const promises_1 = require("node:fs/promises");
const node_path_1 = __importDefault(require("node:path"));
const config_1 = require("./config");
function validateSession(value) { if (!value || !/^[-_a-zA-Z0-9]{1,80}$/.test(value.id) || typeof value.projectId !== 'string' || !/^[-_a-zA-Z0-9]{1,80}$/.test(value.projectId) || typeof value.title !== 'string' || value.title.length > 200 || !Array.isArray(value.messages) || value.messages.length > 300 || value.messages.some((m) => !m || !['user', 'assistant'].includes(m.role) || typeof m.content !== 'string' || m.content.length > 90000) || JSON.stringify(value).length > 1000000)
    throw new Error('Invalid coding session'); if (value.run && (!Array.isArray(value.run.transcript) || !Array.isArray(value.run.events) || typeof value.run.goal !== 'string' || typeof value.run.id !== 'string' || !Array.isArray(value.run.plan) || typeof value.run.answer !== 'string' || value.run.transcript.length > 100 || value.run.transcript.some((m) => !m || !['user', 'assistant'].includes(m.role) || typeof m.content !== 'string')))
    throw new Error('Invalid run checkpoint'); return { id: value.id, projectId: value.projectId, title: value.title, messages: value.messages, run: value.run, updatedAt: Number.isFinite(value.updatedAt) ? value.updatedAt : Date.now(), revision: value.revision }; }
async function atomicJson(file, value) { await (0, promises_1.mkdir)(node_path_1.default.dirname(file), { recursive: true, mode: 0o700 }); const tmp = file + '.' + crypto.randomUUID() + '.tmp'; await (0, promises_1.writeFile)(tmp, JSON.stringify(value), { mode: 0o600 }); try {
    await (0, promises_1.rename)(tmp, file);
}
finally {
    await (0, promises_1.unlink)(tmp).catch(() => { });
} }
class DeviceStore {
    projectId;
    constructor(projectId) {
        this.projectId = projectId;
    }
    get folder() { return node_path_1.default.join((0, config_1.cliHome)(), 'projects', this.projectId); }
    async load(id) { if (!/^[-_a-zA-Z0-9]{1,80}$/.test(id))
        throw new Error('Invalid session ID'); try {
        return validateSession(JSON.parse(await (0, promises_1.readFile)(node_path_1.default.join(this.folder, 'sessions', id + '.json'), 'utf8')));
    }
    catch (e) {
        if (e.code === 'ENOENT')
            return;
        throw e;
    } }
    async save(session) { await atomicJson(node_path_1.default.join(this.folder, 'sessions', session.id + '.json'), session); const recall = new recall_1.DeviceRecall(this.folder); try {
        recall.index(session);
    }
    finally {
        recall.close();
    } }
    async list() { let names = []; try {
        names = await (0, promises_1.readdir)(node_path_1.default.join(this.folder, 'sessions'));
    }
    catch (e) {
        if (e.code !== 'ENOENT')
            throw e;
    } const sessions = await Promise.all(names.filter(n => n.endsWith('.json')).map(n => this.load(n.slice(0, -5)))); return sessions.filter((s) => !!s).sort((a, b) => b.updatedAt - a.updatedAt); }
    async search(query) { const recall = new recall_1.DeviceRecall(this.folder); try {
        for (const session of await this.list())
            recall.index(session);
        return recall.search(query);
    }
    finally {
        recall.close();
    } }
    async records() { try {
        return JSON.parse(await (0, promises_1.readFile)(node_path_1.default.join(this.folder, 'memory.json'), 'utf8'));
    }
    catch (e) {
        if (e.code === 'ENOENT')
            return [];
        throw e;
    } }
    async shared() { try {
        return JSON.parse(await (0, promises_1.readFile)(node_path_1.default.join(this.folder, 'shared.json'), 'utf8'));
    }
    catch (e) {
        if (e.code === 'ENOENT')
            return;
        throw e;
    } }
    async saveShared(context) { await atomicJson(node_path_1.default.join(this.folder, 'shared.json'), context); }
    async replaceNotes(records) { await atomicJson(node_path_1.default.join(this.folder, 'memory.json'), records); }
    async note(record) { const records = await this.records(); await atomicJson(node_path_1.default.join(this.folder, 'memory.json'), [...records.filter(r => r.id !== record.id), record]); }
    async audit(entry) { await (0, promises_1.mkdir)(node_path_1.default.join(this.folder, 'audit'), { recursive: true, mode: 0o700 }); await atomicJson(node_path_1.default.join(this.folder, 'audit', crypto.randomUUID() + '.json'), entry); }
    async lock() { await (0, promises_1.mkdir)(this.folder, { recursive: true, mode: 0o700 }); const file = node_path_1.default.join(this.folder, 'active.pid'); let handle; try {
        handle = await (0, promises_1.open)(file, 'wx', 0o600);
    }
    catch (e) {
        if (e.code !== 'EEXIST')
            throw e;
        const pid = Number(await (0, promises_1.readFile)(file, 'utf8'));
        try {
            process.kill(pid, 0);
            throw new Error('Another Nova CLI is using this project. Close it first.');
        }
        catch (err) {
            if (err.code !== 'ESRCH')
                throw err;
        }
        await (0, promises_1.unlink)(file);
        handle = await (0, promises_1.open)(file, 'wx', 0o600);
    } await handle.writeFile(String(process.pid)); return async () => { await handle.close(); await (0, promises_1.unlink)(file).catch(() => { }); }; }
}
exports.DeviceStore = DeviceStore;
