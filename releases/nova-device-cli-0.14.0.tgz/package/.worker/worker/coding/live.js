"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LiveSessions = void 0;
const store_1 = require("./store");
const valid = (id) => { if (!/^[-_a-zA-Z0-9]{1,80}$/.test(id))
    throw new Error('Invalid session ID'); return id; };
class LiveSessions {
    database;
    now;
    constructor(database, now = () => Date.now()) {
        this.database = database;
        this.now = now;
    }
    list(scope) { return this.database.list(scope, 'live:').map(({ holder, leaseId, controls, ...value }) => ({ ...value, active: value.status === 'running' && value.expiresAt > this.now(), session: this.database.get(scope, 'session:' + value.sessionId) })); }
    claim(scope, holder, sessionInput) { const session = (0, store_1.validateSession)(sessionInput); return this.database.transaction(() => { const key = 'live:' + session.id, old = this.database.get(scope, key), saved = this.database.get(scope, 'session:' + session.id); if (old?.status === 'running' && old.expiresAt > this.now())
        throw Object.assign(new Error('This session is active on another interface. Watch it or request a stop before resuming.'), { status: 409 }); if (saved && saved.revision !== session.revision)
        throw Object.assign(new Error('Session revision changed. Reload it before resuming.'), { status: 409 }); if (!saved && this.database.list(scope, 'session:').length >= 200)
        throw new Error('Session limit reached'); const revision = (saved?.revision || 0) + 1; this.database.put(scope, 'session:' + session.id, { ...session, revision }); const state = { sessionId: session.id, holder, leaseId: crypto.randomUUID(), expiresAt: this.now() + 45000, status: 'running', controls: [], updatedAt: this.now() }; this.database.put(scope, key, state); return { leaseId: state.leaseId, revision, expiresAt: state.expiresAt }; }); }
    checkpoint(scope, holder, id, leaseId, sessionInput, status = 'running') { valid(id); if (!['running', 'paused', 'completed', 'failed'].includes(status))
        throw new Error('Invalid live status'); const session = (0, store_1.validateSession)(sessionInput); if (session.id !== id)
        throw new Error('Session mismatch'); return this.database.transaction(() => { const old = this.database.get(scope, 'live:' + id), saved = this.database.get(scope, 'session:' + id); if (!old || old.leaseId !== leaseId || old.holder !== holder || old.status !== 'running' || old.expiresAt <= this.now())
        throw Object.assign(new Error('Live session lease expired or changed; stop this run and reload'), { status: 409 }); if (saved?.revision !== session.revision)
        throw Object.assign(new Error('Session revision changed'), { status: 409 }); const revision = (saved?.revision || 0) + 1; this.database.put(scope, 'session:' + id, { ...session, revision }); const controls = old.controls; this.database.put(scope, 'live:' + id, { ...old, controls: [], status, expiresAt: status === 'running' ? this.now() + 45000 : this.now(), updatedAt: this.now() }); return { revision, controls, expiresAt: status === 'running' ? this.now() + 45000 : this.now() }; }); }
    control(scope, id, input) { valid(id); if (!input || !['stop', 'steer'].includes(input.type) || input.type === 'steer' && (typeof input.text !== 'string' || !input.text.trim() || input.text.length > 4000))
        throw new Error('Invalid session control'); return this.database.transaction(() => { const state = this.database.get(scope, 'live:' + id); if (!state || state.status !== 'running' || state.expiresAt <= this.now())
        throw new Error('Session is not running'); if (state.controls.length >= 10)
        throw new Error('Ten instructions already queued'); const item = { id: crypto.randomUUID(), type: input.type, text: input.type === 'steer' ? input.text.trim() : undefined }; this.database.put(scope, 'live:' + id, { ...state, controls: [...state.controls, item], updatedAt: this.now() }); return { queued: true, id: item.id }; }); }
}
exports.LiveSessions = LiveSessions;
