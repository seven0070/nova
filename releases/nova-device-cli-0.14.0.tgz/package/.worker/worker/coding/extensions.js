"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SkillExtensions = void 0;
const promises_1 = require("node:fs/promises");
const node_path_1 = __importDefault(require("node:path"));
const node_crypto_1 = require("node:crypto");
const config_1 = require("./config");
const store_1 = require("./store");
const framework_1 = require("../../lib/agent/framework");
const slug = (id) => { if (!/^[a-z0-9-]{1,60}$/.test(id))
    throw new Error('Invalid extension ID'); return id; };
const digest = (value) => (0, node_crypto_1.createHash)('sha256').update(JSON.stringify(value)).digest('hex');
function validate(value) { if (!value || typeof value.version !== 'string' || !/^\d+\.\d+\.\d+$/.test(value.version) || typeof value.description !== 'string' || value.description.length > 1000 || !Array.isArray(value.skills) || !value.skills.length || value.skills.length > 30)
    throw new Error('Invalid declarative extension manifest'); slug(value.id); const skills = value.skills.map((s) => (0, framework_1.parseSkill)(JSON.stringify(s))); if (new Set(skills.map(s => s.name)).size !== skills.length)
    throw new Error('Duplicate skill names'); const content = { id: value.id, version: value.version, description: value.description, skills }; return { summary: { id: value.id, version: value.version, description: value.description, tools: [...new Set(skills.flatMap(s => s.steps.map(t => t.name)))], digest: digest(content) }, skills }; }
class SkillExtensions {
    get folder() { return node_path_1.default.join((0, config_1.cliHome)(), 'extensions'); }
    async inspect(folder) { const file = node_path_1.default.resolve(folder, 'nova-extension.json'), stat = await (0, promises_1.lstat)(file); if (!stat.isFile() || stat.isSymbolicLink() || stat.size > 900000)
        throw new Error('Supply a regular nova-extension.json under 900 KB'); return validate(JSON.parse(await (0, promises_1.readFile)(file, 'utf8'))); }
    async install(bundle) { const checked = validate({ ...bundle.summary, skills: bundle.skills }); if (checked.summary.digest !== bundle.summary.digest)
        throw new Error('Extension changed after review'); await (0, store_1.atomicJson)(node_path_1.default.join(this.folder, slug(bundle.summary.id) + '.json'), checked); return checked.summary; }
    async list() { let names = []; try {
        names = await (0, promises_1.readdir)(this.folder);
    }
    catch (e) {
        if (e.code !== 'ENOENT')
            throw e;
    } return Promise.all(names.filter(n => /^[a-z0-9-]+\.json$/.test(n)).map(async (n) => { const raw = JSON.parse(await (0, promises_1.readFile)(node_path_1.default.join(this.folder, n), 'utf8')), checked = validate({ ...raw.summary, skills: raw.skills }); if (checked.summary.digest !== raw.summary.digest)
        throw new Error('Installed extension integrity check failed: ' + n); return checked; })); }
    async records() { const bundles = await this.list(), names = new Set(); return bundles.flatMap(b => b.skills.flatMap(s => { if (names.has(s.name))
        throw new Error('Installed extensions collide on skill ' + s.name); names.add(s.name); return [{ id: 'extension:' + b.summary.id + ':' + s.name, kind: 'file', name: 'skills/' + s.name + '.json', content: JSON.stringify(s), updatedAt: 0 }, { id: 'extension-doc:' + b.summary.id + ':' + s.name, kind: 'file', name: 'skills/' + s.name + '/SKILL.md', content: (0, framework_1.skillDocument)(s, 1), updatedAt: 0 }]; })); }
    async remove(id) { await (0, promises_1.unlink)(node_path_1.default.join(this.folder, slug(id) + '.json')); }
}
exports.SkillExtensions = SkillExtensions;
