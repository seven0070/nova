"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deviceDoctor = deviceDoctor;
const node_child_process_1 = require("node:child_process");
const node_util_1 = require("node:util");
const gateway_1 = require("../lib/agent/gateway");
async function deviceDoctor(routes = []) { const execute = (0, node_util_1.promisify)(node_child_process_1.execFile); const checks = await Promise.all(['git', 'docker'].map(async (name) => { try {
    const result = await execute(name, [name === 'git' ? '--version' : 'version'], { timeout: 5000, maxBuffer: 5000 });
    return { name, ready: true, detail: result.stdout.split('\n')[0] };
}
catch {
    return { name, ready: false, detail: name === 'docker' ? 'Install/start Docker for sandboxed commands' : 'Executable unavailable' };
} })); const models = await Promise.all(routes.filter(r => (0, gateway_1.isLocal)(r.config.base)).map(async (r) => { try {
    const response = await fetch(r.config.base.replace(/\/+$/, '') + '/models', { headers: r.config.key ? { Authorization: 'Bearer ' + r.config.key } : {}, redirect: 'error', signal: AbortSignal.timeout(5000) });
    if (!response.ok)
        throw new Error();
    const data = await response.json();
    const ids = (data.data || []).map((m) => m.id);
    return { id: r.id, reachable: true, modelPresent: ids.includes(r.config.model), models: ids.slice(0, 30) };
}
catch {
    return { id: r.id, reachable: false, modelPresent: false };
} })); return { node: process.version, platform: process.platform, checks, localModels: models, note: 'A reachable endpoint does not prove model quality. No models or services are installed by this check.' }; }
