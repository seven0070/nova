"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadDeviceGateway = loadDeviceGateway;
const promises_1 = require("node:fs/promises");
const gateway_1 = require("../lib/agent/gateway");
const http_1 = require("../lib/agent/http");
async function loadDeviceGateway() { if (!process.env.NOVA_ROUTER_FILE)
    return; const raw = await (0, promises_1.readFile)(process.env.NOVA_ROUTER_FILE, 'utf8'); if (raw.length > 100000)
    throw new Error('Router configuration too large'); const input = JSON.parse(raw); if (!Array.isArray(input.routes) || !input.routes.length)
    throw new Error('Router file needs routes'); const policy = (0, gateway_1.validatePolicy)(input); const candidates = input.routes.map((r) => { if (typeof r.base !== 'string' || typeof r.model !== 'string' || !r.model || r.model.length > 200 || !['openai', 'anthropic'].includes(r.protocol) || r.keyEnv && (!/^NOVA_[A-Z0-9_]+_KEY$/.test(r.keyEnv) || typeof r.keyEnv !== 'string'))
    throw new Error('Invalid provider route'); const url = new URL(r.base); if (url.username || url.password || url.search || url.hash)
    throw new Error('Credentials do not belong in route URLs'); if (!(0, gateway_1.isLocal)(r.base))
    (0, http_1.publicHttps)(r.base);
else if (!['http:', 'https:'].includes(url.protocol))
    throw new Error('Invalid local model protocol'); const key = r.keyEnv ? process.env[r.keyEnv] || '' : ''; if (!key && !(0, gateway_1.isLocal)(r.base) && r.enabled)
    throw new Error('Missing server key for route ' + r.id); return { ...policy.routes.find(p => p.id === r.id), name: typeof r.name === 'string' ? r.name.slice(0, 100) : r.id, config: { base: r.base, key, model: r.model, protocol: r.protocol, system: '' } }; }); return { policy, candidates }; }
