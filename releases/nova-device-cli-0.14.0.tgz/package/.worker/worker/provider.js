"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.providerUrl = providerUrl;
exports.model = model;
const router_1 = require("./router");
const gateway_1 = require("../lib/agent/gateway");
const model_client_1 = require("../lib/agent/model-client");
const model_client_2 = require("../lib/agent/model-client");
const http_1 = require("../lib/agent/http");
function providerUrl() { const base = process.env.NOVA_MODEL_BASE || ''; const url = new URL(base); if (!['localhost', '127.0.0.1', '[::1]'].includes(url.hostname))
    (0, http_1.publicHttps)(base); return base.replace(/\/+$/, ''); }
async function model(system, messages, signal) { const gateway = await (0, router_1.loadDeviceGateway)(); if (gateway) {
    const selected = process.env.NOVA_ROUTE;
    const candidates = selected && selected !== 'auto' ? gateway.candidates.filter(r => 'route:' + r.id === selected) : gateway.candidates;
    if (selected && selected !== 'auto' && !candidates.length)
        throw new Error('Choose auto or route:ID from the configured local router');
    const routed = await (0, gateway_1.openGateway)(selected && selected !== 'auto' ? { ...gateway.policy, fallback: false } : gateway.policy, candidates, system, messages, signal, true, false);
    const data = await routed.response.json();
    return { text: (0, model_client_1.replyText)(data, routed.protocol), usage: data.usage, model: routed.model };
} return (0, model_client_2.requestModel)({ base: providerUrl(), key: process.env.NOVA_MODEL_KEY || '', model: process.env.NOVA_MODEL || '', protocol: process.env.NOVA_MODEL_PROTOCOL || 'openai', system, fallbackModel: process.env.NOVA_FALLBACK_MODEL }, system, messages, signal, true); }
